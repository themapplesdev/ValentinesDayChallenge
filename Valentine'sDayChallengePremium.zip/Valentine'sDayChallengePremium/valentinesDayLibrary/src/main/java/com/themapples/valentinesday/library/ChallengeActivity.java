/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.themapples.valentinesday.library;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.TextView;


/**
 * Activity for displaying a new challenge; the player has the choice to perform it or skip it
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class ChallengeActivity extends Activity {

  private String mActivePlayer;
  private String mInactivePlayer;
  private String mNamePlayer1;
  private String mNamePlayer2;
  private int mScorePlayer1;
  private int mScorePlayer2;
  private int mTurnNumber;
  private int mGameTotalRounds;
  private int mCurrentRound;
  private Boolean mSoundOn;
  private Boolean rightAfterConfigurationChanged;
  private TextView skipTextView;
  private TextView doneTextView;
  private MediaPlayer mGameActivitySound;
  private SharedPreferences mSharedPrefs;
  private SlideButton mSlideButton;
  private static final String TAG = "ChallengeActivity";

  /**
   * Activity method called when the activity is first created
   */
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_challenge);

    String currentChallenge = "";
    rightAfterConfigurationChanged = false;

    mSharedPrefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
    mSoundOn = mSharedPrefs.getBoolean("soundOn", true);

    if (mSoundOn) {
      mGameActivitySound = MediaPlayer.create(getBaseContext(),
          com.themapples.valentinesday.library.R.raw.game_activity_sound);
      PlaySound(mGameActivitySound, false);
    }

    boolean gameExists = mSharedPrefs.getBoolean("gameExists", false);

    // a valid game is in progress
    if (gameExists) {
      // get game parameters and its current state
      mInactivePlayer = mSharedPrefs.getString("inactivePlayer", "");
      mActivePlayer = mSharedPrefs.getString("activePlayer", "");
      mNamePlayer1 = mSharedPrefs.getString("namePlayer1", "");
      mNamePlayer2 = mSharedPrefs.getString("namePlayer2", "");
      currentChallenge = mSharedPrefs.getString("currentChallenge", "");
      mScorePlayer1 = mSharedPrefs.getInt("scorePlayer1", 0);
      mScorePlayer2 = mSharedPrefs.getInt("scorePlayer2", 0);
      mGameTotalRounds = mSharedPrefs.getInt("gameTotalRounds", 0);
      mTurnNumber = mSharedPrefs.getInt("turnNumber", 0);
      mCurrentRound = (mTurnNumber + 1) / 2;
    }
    // this activity should not never have been reached without an ongoing valid game
    else {
      Log.wtf(TAG, getString(R.string.error_should_not_be_here_at_all));
    }

    // replace the names placeholders with the actual players' names
    currentChallenge = currentChallenge.replaceAll("%inactive%", mInactivePlayer);
    currentChallenge = currentChallenge.replaceAll("%active%", mActivePlayer);

    TextView challengeRoundNumberTextView =
        (TextView) findViewById(R.id.challengeRoundNumberTextView);
    challengeRoundNumberTextView.setText("Round: " + mCurrentRound + " of " + mGameTotalRounds);

    // load custom font
    Typeface customFont = Typeface.createFromAsset(getAssets(), "ArchitectsDaughter.ttf");
    TextView activePlayerNameTextView = (TextView) findViewById(R.id.activePlayerNameTextView);
    activePlayerNameTextView.setText(mActivePlayer);
    activePlayerNameTextView.setTypeface(customFont);

    TextView challengeForTextView = (TextView) findViewById(R.id.challengeForTextView);
    challengeForTextView.setTypeface(customFont);

    TextView challengePlayerScore1TextView =
        (TextView) findViewById(R.id.challengePlayerScore1TextView);
    challengePlayerScore1TextView.setText(mNamePlayer1 + ": " + mScorePlayer1);

    TextView challengePlayerScore2TextView =
        (TextView) findViewById(R.id.challengePlayerScore2TextView);
    challengePlayerScore2TextView.setText(mNamePlayer2 + ": " + mScorePlayer2);

    TextView challengeTextView = (TextView) findViewById(R.id.challengeTextView);
    challengeTextView.setText(currentChallenge);
    challengeTextView.setTypeface(customFont);
    challengeTextView.setMovementMethod(new ScrollingMovementMethod());

    skipTextView = (TextView) findViewById(R.id.skipTextView);
    skipTextView.setTypeface(customFont);
    doneTextView = (TextView) findViewById(R.id.doneTextView);
    doneTextView.setTypeface(customFont);

    // call the methods from the abstract SlideButton listener interface
    handleSlideButton();

  }


  /**
   * Activity method called when the system is about to start resuming a previous activity
   */
  @Override
  protected void onPause() {
    super.onPause();

    if (mSoundOn) {
      if (mGameActivitySound != null) {
        if (mGameActivitySound.isPlaying() || mGameActivitySound.isLooping()) {
          mGameActivitySound.stop();
        }
        mGameActivitySound.reset();
        mGameActivitySound.release();
        mGameActivitySound = null;
      }
    }

    // save the game parameters when activity is not visible anymore
    mSharedPrefs.edit().putString("activePlayer", mActivePlayer).apply();
    mSharedPrefs.edit().putString("inactivePlayer", mInactivePlayer).apply();
    mSharedPrefs.edit().putString("namePlayer1", mNamePlayer1).apply();
    mSharedPrefs.edit().putString("namePlayer2", mNamePlayer2).apply();
    mSharedPrefs.edit().putInt("scorePlayer1", mScorePlayer1).apply();
    mSharedPrefs.edit().putInt("scorePlayer2", mScorePlayer2).apply();
    mSharedPrefs.edit().putInt("gameTotalRounds", mGameTotalRounds).apply();
    mSharedPrefs.edit().putInt("turnNumber", mTurnNumber).apply();
    mSharedPrefs.edit().putInt("currentRound", mCurrentRound).apply();
    mSharedPrefs.edit().putString("lastGameActivity", "ChallengeActivity").apply();
  }


  /**
   * Activity method called when the activity has detected the user's press of the back key
   */
  @Override
  public void onBackPressed() {

    // store the last game activity, in oder to be able to restore it on resume game
    mSharedPrefs.edit().putString("lastGameActivity", "ChallengeActivity").apply();

    try {
  /* since project classes are not visible in libraries,
  reflection is used to access the application menu */
      Intent intent = new Intent(getBaseContext(),
          Class.forName(getApplicationContext().getPackageName() + ".MenuActivity"));
      intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
      startActivity(intent);
      finish();
    }
    catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
  }


  /**
   * Method which is called when the screen rotates.
   * onCreate is no longer called when screen rotates due to manifest android:configChanges
   *
   * @param newConfig the new device configuration
   */
  @Override
  public void onConfigurationChanged(Configuration newConfig) {
    super.onConfigurationChanged(newConfig);

    rightAfterConfigurationChanged = true;

    // reset the thumb image to the inactive state
    mSlideButton.setThumb(getResources().getDrawable(R.drawable.slider_thumb_inactive));

    // hide the "skip" and "done" labels
    skipTextView.setVisibility(View.INVISIBLE);
    doneTextView.setVisibility(View.INVISIBLE);

  }


  /**
   * Implements the methods from the abstract SlideButton listener interface
   *
   */
  private void handleSlideButton() {

    final View view = this.findViewById(android.R.id.content).getRootView();
    final int textViewFadeDuration = 100;

    // runnable command which shows the skipTextView
    final Runnable showSkipTextView = new Runnable() {
      @Override
      public void run() {
        skipTextView.setVisibility(View.VISIBLE);
      }
    };

    // runnable command which shows the doneTextView
    final Runnable showDoneTextView = new Runnable() {
      @Override
      public void run() {
        doneTextView.setVisibility(View.VISIBLE);
      }
    };

    // runnable command which hides the skipTextView
    final Runnable hideSkipTextView = new Runnable() {
      @Override
      public void run() {
        skipTextView.setVisibility(View.INVISIBLE);
      }
    };

    // runnable command which hides the doneTextView
    final Runnable hideDoneTextView = new Runnable() {
      @Override
      public void run() {
        doneTextView.setVisibility(View.INVISIBLE);
      }
    };

    skipTextView.setVisibility(View.INVISIBLE);  // also set invisible in the layout
    doneTextView.setVisibility(View.INVISIBLE);  // also set invisible in the layout

    // the custom SeekBar which will is used to implement slide & unlock
    mSlideButton = (SlideButton) findViewById(R.id.unlockButton);
    mSlideButton.setSlideButtonListener(new SlideButtonListener() {

      // a valid touch on the thumb of the SeekBar
      @Override
      public void handleSlidePressed() {

        // set the thumb image for the active state
        mSlideButton.setThumb(getResources().getDrawable(R.drawable.slider_thumb_active));

        // haptic feedback to signal the user that the thumb is captured and ready to slide
        view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);

        // show the "skip" and "done" labels
        skipTextView.postDelayed(showSkipTextView, textViewFadeDuration);
        doneTextView.postDelayed(showDoneTextView, textViewFadeDuration);
      }

      // the thumb of the SeekBar was released by the user
      @Override
      public void handleSlideReleased() {

        // set the thumb image for the inactive state
        mSlideButton.setThumb(getResources().getDrawable(R.drawable.slider_thumb_inactive));

        // hide the "skip" and "done" labels
        skipTextView.postDelayed(hideSkipTextView, textViewFadeDuration);
        doneTextView.postDelayed(hideDoneTextView, textViewFadeDuration);
      }

      // the thumb was dragged to the left end, meaning that "skip" was successfully selected
      @Override
      public void handleSlideSkip() {

        // haptic feedback to signal the user that the thumb is captured and ready to slide
        view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);

        // hide the entire SlideButton
        mSlideButton.setVisibility(View.INVISIBLE);

        // hide the "skip" and "done" labels
        skipTextView.postDelayed(hideSkipTextView, textViewFadeDuration);
        doneTextView.postDelayed(hideDoneTextView, textViewFadeDuration);

        // switch players
        switchPlayers();

        // start the Challenge or Outcome activity
        Intent intent;
        if (isEndGame()) {
          intent = new Intent(getBaseContext(), OutcomeActivity.class);
        }
        else {
          // increase turn number
          mTurnNumber++;
          intent = new Intent(getBaseContext(), ShakeActivity.class);
        }

        // signal that "skip" was selected
        intent.putExtra("challengeDone", false);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
      }

      // the thumb was dragged to the right end, meaning that "done" was successfully selected
      @Override
      public void handleSlideDone() {

        // haptic feedback to signal the user that the thumb is captured and ready to slide
        view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);

        // hide the entire SlideButton
        mSlideButton.setVisibility(View.INVISIBLE);

        // increase active player's score
        increaseScoreActivePlayer();

        // switch players
        switchPlayers();

        // start the Challenge or Outcome activity
        Intent intent;
        if (isEndGame()) {
          intent = new Intent(getBaseContext(), OutcomeActivity.class);
        }
        else {
          // increase turn number
          mTurnNumber++;
          intent = new Intent(getBaseContext(), ShakeActivity.class);
        }

        // signal that "done" was selected
        intent.putExtra("challengeDone", true);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
      }

      // the thumb was dragged to the right end, meaning that "done" was successfully selected
      @Override
      public void handleSlideDrag() {

        //  reset the progress bar in case the device was rotated while pressing down the slider
        if(rightAfterConfigurationChanged) {
          rightAfterConfigurationChanged = false;
          mSlideButton.setProgress(50);
        }
      }
    });
  }


  /**
   * Method that increases the active player's score
   */
  private void increaseScoreActivePlayer() {

    if (mActivePlayer.equals(mNamePlayer1)) {
      mScorePlayer1++;
    }

    if (mActivePlayer.equals(mNamePlayer2)) {
      mScorePlayer2++;
    }
  }


  /**
   * Method that switches the active and inactive players when the active player's turn is over
   */
  private void switchPlayers() {
    String tempString;
    tempString = mActivePlayer;
    mActivePlayer = mInactivePlayer;
    mInactivePlayer = tempString;
  }


  /**
   * Method that checks for the end of the game
   *
   * @return whether the game has ended or not
   */
  private boolean isEndGame() {
    // the game is over when the number of completed rounds is twice the number of total rounds
    return ((mGameTotalRounds * 2) == mTurnNumber);
  }


  /**
   * Method that plays a sound resource
   *
   * @param mediaPlayer the MediaPlayer object to be played
   * @param playInLoop  whether the sound is to be played once or in a continuous loop
   */
  public void PlaySound(MediaPlayer mediaPlayer, Boolean playInLoop) {

    if (mediaPlayer.isPlaying() || mediaPlayer.isLooping()) {
      mediaPlayer.pause();
    }

    if (playInLoop) {
      mediaPlayer.setLooping(true);
    }
    else {
      mediaPlayer.setLooping(false);
    }

    mediaPlayer.start();
  }

}