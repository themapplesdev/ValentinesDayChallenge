/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.themapples.valentinesday.library;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.themapples.valentinesday.library.FeedReaderContract.FeedEntry;

import java.io.IOException;
import java.util.ArrayList;


/**
 * Class for performing database operations
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class DataBaseAdapter {

  private SQLiteDatabase mDb;
  private DataBaseHelper mDbHelper;
  private static final String TAG = "DataBaseAdapter";

  public DataBaseAdapter(Context context) {
    mDbHelper = new DataBaseHelper(context);
  }


  /**
   * Method that checks if the database already exists
   *
   * @return whether database exists or not
   */
  public Boolean databaseExists() {
    return mDbHelper.checkDataBase();
  }


  /**
   * Method that checks creates the database
   *
   * @return DataBaseAdapter instance
   * @throws SQLiteException if database creation failed
   */
  public DataBaseAdapter createDatabase() throws SQLiteException {

    try {
      mDbHelper.createDataBase();
    }
    catch (IOException mIOException) {
      Log.e(TAG, mIOException.toString());
    }

    return this;
  }


  /**
   * Method that opens the database
   *
   * @return the DataBaseAdapter instance
   * @throws SQLiteException if database could not be opened
   */
  public DataBaseAdapter open() throws SQLiteException {
    try {
      mDbHelper.openDataBase();
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    try {
      mDbHelper.close();
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    try {
      mDb = mDbHelper.getReadableDatabase();
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    return this;
  }


  /**
   * Method that closes the database
   */
  public void close() {
    mDbHelper.close();
  }


  /**
   * Method that returns the id of the Nth record from the challenges table
   *
   * @param rowNumber number of the record for which the index is required
   * @return id of the challenge
   */
  public String getNthChallengeId(int rowNumber) {

    String challengeId = "";
    String[] dbProjection = {
        FeedEntry.COLUMN_NAME_ENTRY_ID,
    };
    String sortOrder = FeedEntry.COLUMN_NAME_ENTRY_ID + " ASC";

    Cursor cursor = mDb.query(
        FeedEntry.TABLE_NAME,                   // the table to query
        dbProjection,                           // the columns to return
        null,                                   // the columns for the WHERE clause
        null,                                   // the values for the WHERE clause
        null,                                   // don't group the rows
        null,                                   // don't filter by row groups
        sortOrder                               // the sort order
    );

    try {
      if (cursor.moveToPosition(rowNumber)) {
        challengeId =
            cursor.getString(cursor.getColumnIndexOrThrow(FeedEntry.COLUMN_NAME_ENTRY_ID));
      }
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    try {
      cursor.close();
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    return challengeId;
  }


  /**
   * Method that receives the text of a challenge given by its id
   *
   * @param challengeId the id of the challenge for which the text is to be retrieved
   * @return index of the given challenge
   */
  public String getChallenge(String challengeId) {

    String challenge = "";
    String[] dbProjection = {
        FeedEntry.COLUMN_NAME_TEXT,
    };
    String sortOrder = FeedEntry.COLUMN_NAME_ENTRY_ID + " ASC";
    String dbSelection = FeedEntry.COLUMN_NAME_ENTRY_ID + "=?";
    String[] dbSelectionArgs = {challengeId};

    Cursor cursor = mDb.query(
        FeedEntry.TABLE_NAME,                   // the table to query
        dbProjection,                           // the columns to return
        dbSelection,                            // the columns for the WHERE clause
        dbSelectionArgs,                        // the values for the WHERE clause
        null,                                   // don't group the rows
        null,                                   // don't filter by row groups
        sortOrder                               // the sort order
    );

    try {
      if (cursor.moveToFirst()) {
        challenge = cursor.getString(cursor.getColumnIndexOrThrow(FeedEntry.COLUMN_NAME_TEXT));
      }
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    try {
      cursor.close();
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    /* replace the \\n character returned from the database instead of the \n value.
    There's no newline character in SQL and \n is seen as two characters, the \ is escaped
    automatically, so \\n is received and needs to be corrected */
    challenge = challenge.replace("\\n", "\n");

    return challenge;
  }


  /**
   * Method that inserts a new challenge to the challenges table
   *
   * @param challengeText the challenge which is to be retrieved
   * @return index of the newly inserted challenge
   */
  public long addChallenge(String challengeText) {

    long newRowId = 0;

    try {
      SQLiteDatabase db = mDbHelper.getWritableDatabase();

      // create a new map of values, where column names are the keys
      ContentValues values = new ContentValues();
      values.put(FeedEntry.COLUMN_NAME_TEXT, challengeText);
      values.put(FeedEntry.COLUMN_NAME_EDITABLE, "1");

      // insert the new row, returning its primary key value
      newRowId = db.insert(
          FeedEntry.TABLE_NAME,
          null,
          values);

      try {
        db.close();
      }
      catch (SQLiteException mSQLiteException) {
        Log.e(TAG, mSQLiteException.toString());
      }
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    return newRowId;
  }


  /**
   * Method that retrieves all the user-added challenges
   *
   * @return ArrayList of the user-added challenges
   */
  public ArrayList<String> getMyChallenges() {

    ArrayList<String> results = new ArrayList<>();

    String[] dbProjection = {
        FeedEntry.COLUMN_NAME_ENTRY_ID,
        FeedEntry.COLUMN_NAME_TEXT,
    };

    String sortOrder = FeedEntry.COLUMN_NAME_ENTRY_ID + " ASC";
    String dbSelection = FeedEntry.COLUMN_NAME_EDITABLE + "=?";
    //all custom challenges have their _editable column value set to 1
    String[] dbSelectionArgs = {"1"};

    Cursor cursor = mDb.query(
        FeedEntry.TABLE_NAME,                       // the table to query
        dbProjection,                               // the columns to return
        dbSelection,                                // the columns for the WHERE clause
        dbSelectionArgs,                            // the values for the WHERE clause
        null,                                       // don't group the rows
        null,                                       // don't filter by row groups
        sortOrder                                   // the sort order
    );

    try {
      if (cursor != null && cursor.getCount() != 0) {
        if (cursor.moveToFirst()) {
          do {
            String challengeText = cursor.getString(cursor.getColumnIndex("_text"));
            results.add(challengeText);
          }
          while (cursor.moveToNext());
        }
      }
      else {
        results = null;
      }
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }
    finally {
      if (cursor != null) {
        try {
          cursor.close();
        }
        catch (SQLiteException mSQLiteException) {
          Log.e(TAG, mSQLiteException.toString());
        }
      }
    }

    return results;
  }


  /**
   * Method that retrieves the list of all the challenge ids
   *
   * @return ArrayList of all the challenge ids
   */
  public ArrayList<String> getAllChallengeIds() {

    ArrayList<String> results = new ArrayList<>();

    String[] dbProjection = {
        FeedEntry.COLUMN_NAME_ENTRY_ID,
    };

    String sortOrder = FeedEntry.COLUMN_NAME_ENTRY_ID + " ASC";
    // selection and selection args not specified equivalent to select *

    Cursor cursor = mDb.query(
        FeedEntry.TABLE_NAME,                       // the table to query
        dbProjection,                               // the columns to return
        null,                                       // the columns for the WHERE clause
        null,                                       // the values for the WHERE clause
        null,                                       // don't group the rows
        null,                                       // don't filter by row groups
        sortOrder                                   // the sort order
    );

    try {

      if (cursor != null && cursor.getCount() != 0) {
        if (cursor.moveToFirst()) {
          do {
            String challengeText = cursor.getString(cursor.getColumnIndex("_id"));
            results.add(challengeText);
          } while (cursor.moveToNext());
        }
      }
      else {
        results = null;
      }
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }
    finally {
      if (cursor != null) {
        try {
          cursor.close();
        }
        catch (SQLiteException mSQLiteException) {
          Log.e(TAG, mSQLiteException.toString());
        }
      }
    }

    return results;
  }


  /**
   * Method that updates the text of a custom challenge specified by its id
   *
   * @param challengeId   id of the challenge which is to be updated
   * @param challengeText the new text of the challenge
   * @return result of the record update operation
   */
  public Boolean updateChallenge(String challengeId, String challengeText) {

    Boolean updateSuccess = false;

    // challenge id not found or challenge is not editable
    if (challengeId.equals("") || challengeId.equals("0") || challengeId.length() == 0) {
      return false;
    }

    ContentValues contentValues = new ContentValues();
    contentValues.put(FeedEntry.COLUMN_NAME_ENTRY_ID, challengeId);
    contentValues.put(FeedEntry.COLUMN_NAME_TEXT, challengeText);
    contentValues.put(FeedEntry.COLUMN_NAME_EDITABLE, 1);
    String where = FeedEntry.COLUMN_NAME_ENTRY_ID + "=" + challengeId;

    try {
      mDb.update(FeedEntry.TABLE_NAME, contentValues, where, null);
      updateSuccess = true;
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    return updateSuccess;
  }


  /**
   * Method that deletes a challenge given by its id
   *
   * @param challengeId id of the challenge which is to be deleted
   * @return result of the record delete operation
   */
  public Boolean deleteChallenge(String challengeId) {

    Boolean deleteSuccess = false;

    try {
      if (mDb.delete(FeedEntry.TABLE_NAME,
          FeedEntry.COLUMN_NAME_ENTRY_ID + "=" + challengeId, null) > 0) {
        deleteSuccess = true;
      }
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    return deleteSuccess;
  }

}