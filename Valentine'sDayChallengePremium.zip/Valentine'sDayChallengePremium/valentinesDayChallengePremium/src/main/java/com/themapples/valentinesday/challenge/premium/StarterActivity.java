/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.themapples.valentinesday.challenge.premium;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteException;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.TextView;

import com.themapples.valentinesday.library.DataBaseAdapter;

/**
 * Launcher activity, which displays the initial logo for a period of time and automatically switches to the Menu activity
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class StarterActivity extends Activity {

  private DataBaseAdapter mDbAdapter;
  private SharedPreferences mSharedPrefs;
  private Handler mHandler = new Handler();
  private static final String TAG = "StarterActivity";

  /**
   * Activity method called when the activity is first created
   */
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_starter);

    // set custom font to Menu title
    TextView splashThemApplesTextView = (TextView) findViewById(R.id.splashThemApplesTextView);
    Typeface customFont = Typeface.createFromAsset(getAssets(), "Calibri.ttf");
    splashThemApplesTextView.setTypeface(customFont);

    final int DEFAULT_ROUNDS_PREMIUM = 15;
    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());

    final Context context = getApplicationContext();
    mSharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
    Boolean firstRun = mSharedPrefs.getBoolean("firstRun", true);
    mDbAdapter = new DataBaseAdapter(getApplicationContext());

    // it's the app's first run
    if (firstRun || !mDbAdapter.databaseExists()) {
      // asynchronously copy the database from the apk, to avoid overworking the UI thread
      new AsynchronousDatabaseCreateTask().execute();
    }

    // save the default total rounds for the premium app
    if (!sharedPrefs.contains("totalRounds")) {
      sharedPrefs.edit().putInt("totalRounds", DEFAULT_ROUNDS_PREMIUM).apply();
    }
  }


  /**
   * Activity method called when the activity will start interacting with the user
   */
  @Override
  protected void onResume() {
    super.onResume();

    final int LAUNCHER_DURATION = 2500; // time (in ms) after which the Menu activity is started

    // the Starter activity will automatically show the Menu activity after the time duration
    mHandler.removeCallbacksAndMessages(null);
    mHandler.postDelayed(new Runnable() {

      @Override
      public void run() {
        Intent intent = new Intent(getBaseContext(), MenuActivity.class);
        intent.putExtra("reachedFromIntro", true);
        startActivity(intent);
        finish();

        // activity transition animation will fade out - fade in
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);

      }
    }, LAUNCHER_DURATION);
  }


  /**
   * Activity method called when the system is about to start resuming a previous activity
   */
  @Override
  protected void onPause() {
    super.onPause();

    // de-register the delay handler
    mHandler.removeCallbacksAndMessages(null);
  }


  /**
   * Asynchronous task copies the pre-built database from the apk to the device internal storage
   */
  private class AsynchronousDatabaseCreateTask extends AsyncTask<String, Integer, Boolean> {

    /**
     * Method invoked on the background thread immediately after onPreExecute finishes executing
     *
     * @param params the parameters sent to the task upon execution
     */
    @Override
    protected Boolean doInBackground(String... params) {

      try {
        mDbAdapter.createDatabase();
      }
      catch (SQLiteException mSQLiteException) {
        Log.e(TAG, mSQLiteException.toString());
      }

      try {
        mDbAdapter.close();
      }
      catch (SQLiteException mSQLiteException) {
        Log.e(TAG, mSQLiteException.toString());
      }

      return null;
    }

    /**
     * Method invoked on the UI thread after the background computation finishes
     *
     * @param result the result of the background computation
     */
    @Override
    protected void onPostExecute(Boolean result) {
      super.onPostExecute(result);

      // save that the application was successfully run for the first time (and the db copied)
      mSharedPrefs.edit().putBoolean("firstRun", false).apply();
    }
  }

}
