/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.themapples.valentinesday.challenge.premium;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import com.facebook.UiLifecycleHelper;
import com.facebook.widget.LikeView;
import com.themapples.valentinesday.library.ChallengeActivity;
import com.themapples.valentinesday.library.NewGameActivity;
import com.themapples.valentinesday.library.ShakeActivity;


/**
 * Activity which displays the main menu of the application
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class MenuActivity extends Activity {

  private boolean mMusicOn;
  private boolean mShowInfo;
  private SharedPreferences mSharedPrefs;
  private Boolean mGameExists;
  private String mLastGameActivity;
  private CheckBox mCheckBox;
  private AlertDialog mIntroAlertDialog;
  private AlertDialog mNewGameAlertDialog;
  private MediaPlayer mMenuMusic;
  private UiLifecycleHelper uiHelper;
  //private static final String TAG = "MenuActivity";

  /**
   * Activity method called when the activity is first created
   */
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_menu);

    //configure the Facebook UiLifecycleHelper
    uiHelper = new UiLifecycleHelper(this, null);
    uiHelper.onCreate(savedInstanceState);
    // like button for Facebook
    LikeView likeView = (LikeView) findViewById(R.id.likeView);
    likeView.setObjectId(getString(com.themapples.valentinesday.library.R.string.facebook_app_page));
    // or using the facebook id of the page
    /* likeView.setObjectId(
    getString(com.themapples.valentinesday.library.R.string.facebook_id); */
    likeView.setLikeViewStyle(LikeView.Style.STANDARD);
    likeView.setAuxiliaryViewPosition(LikeView.AuxiliaryViewPosition.INLINE);
    likeView.setHorizontalAlignment(LikeView.HorizontalAlignment.LEFT);

    final Context context = getApplicationContext();
    mSharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
    mShowInfo = mSharedPrefs.getBoolean("showInfo", true);
    mMusicOn = mSharedPrefs.getBoolean("musicOn", true);
    mGameExists = mSharedPrefs.getBoolean("gameExists", false);
    mLastGameActivity = mSharedPrefs.getString("lastGameActivity", "");

    // there is no game currently in progress
    if (mLastGameActivity.equals("")) {
      mGameExists = false;
      mSharedPrefs.edit().putBoolean("gameExists", false).apply();
    }

    // set custom font to title
    TextView menuTitleTextView = (TextView) findViewById(R.id.menuTitleTextView);
    Typeface customFont = Typeface.createFromAsset(getAssets(), "ArchitectsDaughter.ttf");
    menuTitleTextView.setTypeface(customFont);

    ImageButton newGameButton = (ImageButton) findViewById(R.id.newGameButton);
    newGameButton.setOnClickListener(new OnClickListener() {

      @Override
      public void onClick(View view) {

        // a game in progress exists
        if (mGameExists) {
          // AlertDialog asking the user for confirmation before starting a new game
          AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MenuActivity.this);
          dialogBuilder.setTitle(
              getString(com.themapples.valentinesday.library.R.string.dialog_title_warning));
          dialogBuilder.setIcon(com.themapples.valentinesday.library.R.drawable.heart);
          dialogBuilder.setMessage(getResources().
              getString(com.themapples.valentinesday.library.R.string.dialog_warning_newgame));
          dialogBuilder.setCancelable(false);
          dialogBuilder.setPositiveButton(
              getString(com.themapples.valentinesday.library.R.string.dialog_button_yes),
              new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {

                  dialog.dismiss();

                  // clear all the data from to the previous game
                  ClearPreviousGameData();

                  Intent intent = new Intent(getBaseContext(), NewGameActivity.class);
                  intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                  startActivity(intent);
                  finish();
                }
              });

          dialogBuilder.setNegativeButton(
              getString(com.themapples.valentinesday.library.R.string.dialog_button_no),
              new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                  dialog.dismiss();
                }
              });

          mNewGameAlertDialog = dialogBuilder.create();
          mNewGameAlertDialog.show();
        }
        // there is no game currently in progress
        else {
          Intent intent = new Intent(getBaseContext(), NewGameActivity.class);
          intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
          startActivity(intent);
          finish();
        }
      }
    });

    ImageButton settingsButton = (ImageButton) findViewById(R.id.settingsButton);
    settingsButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {

        Intent intent = new Intent(getBaseContext(), SettingsActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
      }
    });

    ImageButton resumeButton = (ImageButton) findViewById(R.id.resumeButton);
    // is a previous game exists, enable the resume game button
    if (mGameExists &&
        (mLastGameActivity.equals("ShakeActivity") ||
            mLastGameActivity.equals("ChallengeActivity"))) {
      resumeButton.setEnabled(true);
    }
    // no previous game exists, disable the resume game button
    else {
      resumeButton.setEnabled(false);
    }

    resumeButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {

        // resume game to ShakeActivity
        if (mLastGameActivity.equals("ShakeActivity")) {
          Intent intent = new Intent(getBaseContext(), ShakeActivity.class);
          intent.putExtra("reachedByResume", true);
          intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
          startActivity(intent);
          finish();
        }
        else {
          // resume game to ChallengeActivity
          if (mLastGameActivity.equals("ChallengeActivity")) {
            Intent intent = new Intent(getBaseContext(), ChallengeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
          }
        }
      }
    });

    ImageButton infoButton = (ImageButton) findViewById(R.id.infoButton);
    infoButton.setOnClickListener(new OnClickListener() {

      @Override
      public void onClick(View view) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MenuActivity.this);
        dialogBuilder.setTitle(
            getString(com.themapples.valentinesday.library.R.string.app_commercial_name));
        dialogBuilder.setIcon(com.themapples.valentinesday.library.R.drawable.heart);
        dialogBuilder.setMessage(getResources()
            .getString(com.themapples.valentinesday.library.R.string.dialog_intro_text));
        dialogBuilder.setCancelable(false);
        dialogBuilder.setPositiveButton(
            getString(com.themapples.valentinesday.library.R.string.dialog_button_ok),
            new DialogInterface.OnClickListener() {
              public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
              }
            });

        mIntroAlertDialog = dialogBuilder.create();
        mIntroAlertDialog.show();
      }
    });

    ImageButton myChallengesButton = (ImageButton) findViewById(R.id.myChallengesButton);
    myChallengesButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {
        Intent intent = new Intent(getBaseContext(), MyChallengesActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
      }
    });
  }


  /**
   * Activity method called when the activity is becoming visible to the user
   */
  @Override
  protected void onStart() {
    super.onStart();

    if(mMusicOn) {
      mMenuMusic = MediaPlayer.create(getBaseContext(),
          com.themapples.valentinesday.library.R.raw.menu_music);
      PlaySound(mMenuMusic, true);
    }

    Bundle extras = getIntent().getExtras();
    Boolean reachedFromIntro = extras != null && extras.getBoolean("reachedFromIntro");

    /* Menu activity was not reached by a back press from another activity,
    but from the Starter activity; and showInfo option is on
     */
    if (mShowInfo && reachedFromIntro) {
      View checkBoxView = View.inflate(getBaseContext(), R.layout.dialog_intro, null);
      mCheckBox = (CheckBox) checkBoxView.findViewById(R.id.introDialogCheckBox);

      // AlertDialog which displays a short description of the application
      AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MenuActivity.this);
      dialogBuilder.setView(checkBoxView);
      dialogBuilder.setTitle(
          getString(com.themapples.valentinesday.library.R.string.app_commercial_name));
      dialogBuilder.setIcon(com.themapples.valentinesday.library.R.drawable.heart);
      dialogBuilder.setCancelable(false);
      dialogBuilder.setPositiveButton(
          getString(com.themapples.valentinesday.library.R.string.dialog_button_ok),
          new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

              mSharedPrefs.edit().putBoolean("showInfo", mShowInfo).apply();
              dialog.dismiss();
            }
          });

      mIntroAlertDialog = dialogBuilder.create();
      mIntroAlertDialog.show();
    }

    if (mIntroAlertDialog != null) {
      mCheckBox.setOnClickListener(new OnClickListener() {

        @Override
        public void onClick(View v) {
          mShowInfo = !mCheckBox.isChecked();
        }
      });
    }
  }


  /**
   * Activity method called when the system is about to start resuming a previous activity
   */
  @Override
  protected void onPause() {
    super.onPause();

    if (mIntroAlertDialog != null) {
      mIntroAlertDialog.dismiss();
    }

    if (mNewGameAlertDialog != null) {
      mNewGameAlertDialog.dismiss();
    }

    if (mMusicOn) {
      if (mMenuMusic != null) {
        if (mMenuMusic.isPlaying() || mMenuMusic.isLooping()) {
          mMenuMusic.stop();
        }
        mMenuMusic.reset();
        mMenuMusic.release();
        mMenuMusic = null;
      }
    }
  }


  /**
   * Activity method called when the activity has detected the user's press of the back key
   */
  @Override
  public void onBackPressed() {
    // finish the application when the back button is pressed
    finish();
  }


  /**
   * Callback received as the result data of an Intent object
   *
   * @param requestCode the request which started the activity
   * @param resultCode  the result code returned by the request
   * @param data  additional data of the result
   */
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);

    uiHelper.onActivityResult(requestCode, resultCode, data, null);
  }


  /**
   * Method that clears all the data from the previous game, in order to start a new one
   */
  private void ClearPreviousGameData() {
    mSharedPrefs.edit().putBoolean("gameExists", false).apply();
    mSharedPrefs.edit().putString("activePlayer", "").apply();
    mSharedPrefs.edit().putString("inactivePlayer", "").apply();
    mSharedPrefs.edit().putString("namePlayer1", "").apply();
    mSharedPrefs.edit().putString("namePlayer2", "").apply();
    mSharedPrefs.edit().putInt("scorePlayer1", 0).apply();
    mSharedPrefs.edit().putInt("scorePlayer2", 0).apply();
    mSharedPrefs.edit().putInt("gameRounds", 0).apply();
    mSharedPrefs.edit().putInt("turnNumber", 0).apply();
    mSharedPrefs.edit().putInt("currentRound", 0).apply();
    mSharedPrefs.edit().putString("lastGameActivity", "").apply();
    mSharedPrefs.edit().putString("remainingChallengesList", "").apply();
  }


  /**
   * Method that plays a sound resource
   *
   * @param mediaPlayer the MediaPlayer object to be played
   * @param playInLoop  whether the sound is to be played once or in a continuous loop
   */
  public void PlaySound(MediaPlayer mediaPlayer, Boolean playInLoop) {

    if (mediaPlayer.isPlaying() || mediaPlayer.isLooping()) {
      mediaPlayer.pause();
    }

    if (playInLoop) {
      mediaPlayer.setLooping(true);
    }
    else {
      mediaPlayer.setLooping(false);
    }

    mediaPlayer.start();
  }

}