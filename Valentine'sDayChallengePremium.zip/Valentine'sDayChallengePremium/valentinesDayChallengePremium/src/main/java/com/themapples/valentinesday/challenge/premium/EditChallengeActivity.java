/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.themapples.valentinesday.challenge.premium;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteException;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.method.TextKeyListener;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.themapples.valentinesday.library.DataBaseAdapter;


/**
 * Activity which allows users to update or delete an existing custom challenge
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class EditChallengeActivity extends Activity {

  private TextView mChallengeCharacterCounter;
  private EditText mUpdateChallengeEditText;
  private AlertDialog mDeleteAlertDialog;
  private String mTrueChallengeId;
  private String mOldChallengeText;
  private final int MAX_CHALLENGE_LENGTH = 500;       // also set in layout textview property!
  private static final String TAG = "EditChallengeActivity";

  /**
   * Activity method called when the activity is first created
   */
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_edit_challenge);

    final Context context = getApplicationContext();

    // set custom font to title
    TextView editChallengeTitleTextView = (TextView) findViewById(R.id.editChallengeTitleTextView);
    Typeface customFont = Typeface.createFromAsset(getAssets(), "ArchitectsDaughter.ttf");
    editChallengeTitleTextView.setTypeface(customFont);

    TextView instructionsTextView = (TextView) findViewById(R.id.instructionsTextView);
    SpannableString text = new SpannableString(
        getString(R.string.layout_custom_challenge_example));

    // set different colors to the custom challenge add/edit instructions
    text.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 4, 12, 0);
    text.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 17, 27, 0);
    text.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 104, 112, 0);
    text.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 123, 133, 0);
    instructionsTextView.setText(text, TextView.BufferType.SPANNABLE);
    instructionsTextView.setTypeface(customFont);

    // from the MyChallenges, get the number (not the id!) of the challenge which is to be edited
    Bundle extras = getIntent().getExtras();
    long selectedChallengeRow = extras.getLong("challengeRow");

    DataBaseAdapter dbAdapter = new DataBaseAdapter(getApplicationContext());
    try {
      dbAdapter.open();
      mTrueChallengeId = dbAdapter.getNthChallengeId((int) selectedChallengeRow);
    }
    catch (SQLiteException sqle) {
      Log.e(TAG, sqle.toString());
    }

    try {
      // get the true id of the selected challenge from the database
      mOldChallengeText = dbAdapter.getChallenge(mTrueChallengeId);
    }
    catch (SQLiteException sqle) {
      Log.e(TAG, sqle.toString());
    }

    try {
      dbAdapter.close();
    }
    catch (SQLiteException mSQLiteException) {
      Log.e(TAG, mSQLiteException.toString());
    }

    mUpdateChallengeEditText = (EditText) findViewById(R.id.updateChallengeEditText);
    mUpdateChallengeEditText.setText(mOldChallengeText);

    // set up the characters counter for the challenge update EditText
    mChallengeCharacterCounter = (TextView) findViewById(R.id.challengeCharacterCounter);
    mChallengeCharacterCounter.setText(
        getString(com.themapples.valentinesday.library.R.string.character_counter_label) +
        (MAX_CHALLENGE_LENGTH - mOldChallengeText.length()));

    ImageButton updateChallengeButton = (ImageButton) findViewById(R.id.updateChallengeButton);
    updateChallengeButton.setOnClickListener(new OnClickListener() {

      @Override
      public void onClick(View view) {

        final String newChallengeText = mUpdateChallengeEditText.getText().toString().trim();
        CharSequence text = "";

        //  update attempted with blank text
        if ((newChallengeText.equals("") || newChallengeText.length() == 0)) {
          String blankChallengeError = getString(R.string.dialog_blank_challenge_error);
          showErrorDialogue(blankChallengeError);
        }
        // valid challenge
        else {

          DataBaseAdapter dbAdapter = new DataBaseAdapter(context);

          try {
            dbAdapter.open();
          }
          catch (SQLiteException sqle) {
            Log.e(TAG, sqle.toString());
          }

          try {
            // updating the challenge was successful
            if (dbAdapter.updateChallenge(mTrueChallengeId, newChallengeText)) {
              text = getString(R.string.toast_update_challenge_success);
            }
            // updating the challenge was not successful
            else {
              text = getString(R.string.toast_update_challenge_error);
              Log.w(TAG, getString(R.string.error_database_update));
            }
          }
          catch (SQLiteException sqle) {
            Log.e(TAG, sqle.toString());
          }

          try {
            dbAdapter.close();
          }
          catch (SQLiteException mSQLiteException) {
            Log.e(TAG, mSQLiteException.toString());
          }

          int duration = Toast.LENGTH_SHORT;
          Toast toast = Toast.makeText(context, text, duration);
          toast.show();

          Intent intent = new Intent(getBaseContext(), MyChallengesActivity.class);
          intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
          startActivity(intent);
          finish();
        }
      }
    });

    ImageButton deleteChallengeButton = (ImageButton) findViewById(R.id.deleteChallengeButton);
    deleteChallengeButton.setOnClickListener(new OnClickListener() {

      @Override
      public void onClick(View view) {

        // AlertDialog asking the user for confirmation before deleting a challenge
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(EditChallengeActivity.this);
        dialogBuilder.setTitle(
            getString(com.themapples.valentinesday.library.R.string.dialog_title_warning));
        dialogBuilder.setIcon(com.themapples.valentinesday.library.R.drawable.heart);
        dialogBuilder.setMessage(
            getResources().getString(R.string.dialog_warning_delete_challenge));
        dialogBuilder.setCancelable(false);
        dialogBuilder.setPositiveButton(
            getString(com.themapples.valentinesday.library.R.string.dialog_button_yes),
            new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int id) {

            dialog.dismiss();

            CharSequence text = "";
            DataBaseAdapter dbAdapter = new DataBaseAdapter(context);
            try {
              dbAdapter.open();
            }
            catch (SQLiteException sqle) {
              Log.e(TAG, sqle.toString());
            }

            try {
              // challenge was successfully deleted from the challenges table
              if (dbAdapter.deleteChallenge(mTrueChallengeId)) {

                // delete the id of the challenge from the ongoing game, if there is one
                RemoveFromOngoingGame(mTrueChallengeId);
                text = (getString(R.string.toast_delete_challenge_success));
              }
              // challenge was not successfully deleted from the challenges table
              else {
                text = (getString(R.string.toast_delete_challenge_error));
                Log.w(TAG, getString(R.string.error_database_delete));
              }
            }
            catch (SQLiteException sqle) {
              Log.e(TAG, sqle.toString());
            }

            try {
              dbAdapter.close();
            }
            catch (SQLiteException mSQLiteException) {
              Log.e(TAG, mSQLiteException.toString());
            }

            // clear EditText value
            if (mUpdateChallengeEditText.length() > 0) {
              TextKeyListener.clear(mUpdateChallengeEditText.getText());
            }

            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

            Intent intent = new Intent(getBaseContext(), MyChallengesActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
          }
        });

        dialogBuilder.setNegativeButton(
            getString(com.themapples.valentinesday.library.R.string.dialog_button_no),
            new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int id) {
            dialog.dismiss();
          }
        });

        mDeleteAlertDialog = dialogBuilder.create();
        mDeleteAlertDialog.show();
      }
    });
  }


  /**
   * Activity method called when the activity is becoming visible to the user
   */
  @Override
  protected void onStart() {
    super.onStart();

    mUpdateChallengeEditText.addTextChangedListener(challengeCharacterCounterWatcher);
  }


  /**
   * Activity method called when the activity has detected the user's press of the back key
   */
  @Override
  public void onBackPressed() {

    Intent intent = new Intent(this, MyChallengesActivity.class);
    intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
    startActivity(intent);
    finish();
  }


  /**
   * Method that displays an AlertDialog with a given message
   *
   * @param message text which will appear as the AlertDialog message
   */
  private void showErrorDialogue(String message) {

    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
    dialogBuilder.setTitle(
        getString(com.themapples.valentinesday.library.R.string.dialog_title_error));
    dialogBuilder.setIcon(com.themapples.valentinesday.library.R.drawable.heart);
    dialogBuilder.setMessage(message);
    dialogBuilder.setCancelable(false);

    dialogBuilder.setPositiveButton(
        getString(com.themapples.valentinesday.library.R.string.dialog_button_ok),
        new DialogInterface.OnClickListener() {
      public void onClick(DialogInterface dialog, int id) {
        dialog.dismiss();
      }
    });

    mDeleteAlertDialog = dialogBuilder.create();
    mDeleteAlertDialog.show();
  }


  /**
   * TextWatcher method which is called when the value of the challenge EditText is changed
   */
  private final TextWatcher challengeCharacterCounterWatcher = new TextWatcher() {

    /**
     * Abstract method beforeTextChanged must be implemented to create a TextWatcher
     *
     * @param  s initial text whose content will changed
     * @param  start character position where the initial text will be changed
     * @param  count number of characters whose content will be changed in the initial text
     * @param  after length of the new text which will replace the old one
     */
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    /**
     * Method which updates the character counter when the value of the EditText has changed
     *
     * @param  s new text whose content has changed
     * @param  start character position where the new text has changed
     * @param  before length of the initial text which was replace by the new one
     * @param  count number of characters whose content has changed in the new text
     */
    public void onTextChanged(CharSequence s, int start, int before, int count) {
      mChallengeCharacterCounter.setText(
          getString(com.themapples.valentinesday.library.R.string.character_counter_label) +
              String.valueOf(MAX_CHALLENGE_LENGTH - s.length()));
    }

    /**
     * Abstract method afterTextChanged must be implemented in implement a TextWatcher
     *
     * @param  s text whose content has changed
     */
    public void afterTextChanged(Editable s) {
    }
  };


  /**
   * Method that removes the id of the newly deleted challenge from the game currently in progress
   *
   * @param idToRemove id of the challenge which is to be deleted from the available challenges list
   */
  private void RemoveFromOngoingGame(String idToRemove) {

    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
    Boolean gameExists = sharedPrefs.getBoolean("gameExists", false);

    // a game is currently in progress
    if (gameExists) {
      String remainingChallengesList = sharedPrefs.getString("remainingChallengesList", "");
      remainingChallengesList = remainingChallengesList.replace(idToRemove + " ", "");
      sharedPrefs.edit().putString("remainingChallengesList", remainingChallengesList).apply();
    }
  }

}
