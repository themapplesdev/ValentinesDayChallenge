/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.themapples.valentinesday.challenge.premium;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteException;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.method.TextKeyListener;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.themapples.valentinesday.library.DataBaseAdapter;


/**
 * Activity which allows users to add a custom challenge to the game
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class AddChallengeActivity extends Activity {

  private EditText mNewChallengeEditText;
  private TextView mChallengeCharacterCounter;
  private final int MAX_CHALLENGES_LENGTH = 500;  // this is also set in layout TextView property
  private static final String TAG = "AddChallengeActivity";

  /**
   * Activity method called when the activity is first created
   */
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_add_challenge);

    final Context context = getApplicationContext();

    // set custom font to title
    TextView addNewChallengeTitleTextView = (TextView) findViewById(R.id.addNewChallengeTitleTextView);
    Typeface customFont = Typeface.createFromAsset(getAssets(), "ArchitectsDaughter.ttf");
    addNewChallengeTitleTextView.setTypeface(customFont);


    TextView instructionsTextView = (TextView) findViewById(R.id.instructionsTextView);
    SpannableString text = new SpannableString(
        getString(R.string.layout_custom_challenge_example));
    text.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 4, 12, 0);
    text.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 17, 27, 0);
    text.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 104, 112, 0);
    text.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.black)), 123, 133, 0);
    instructionsTextView.setText(text, TextView.BufferType.SPANNABLE);
    instructionsTextView.setTypeface(customFont);

    // set up the characters counter for the new challenge EditText
    mChallengeCharacterCounter = (TextView) findViewById(R.id.challengeCharacterCounter);
    mChallengeCharacterCounter.setText(
        getString(com.themapples.valentinesday.library.R.string.character_counter_label) +
        MAX_CHALLENGES_LENGTH);

    // clear EditText value
    mNewChallengeEditText = (EditText) findViewById(R.id.newChallengeEditText);
    if (mNewChallengeEditText.length() > 0) {
      TextKeyListener.clear(mNewChallengeEditText.getText());
    }

    ImageButton addNewChallengeButton = (ImageButton) findViewById(R.id.addNewChallengeButton);
    addNewChallengeButton.setOnClickListener(new View.OnClickListener() {

      @Override
      public void onClick(View view) {

        String challengeText = mNewChallengeEditText.getText().toString().trim();

        // blank new challenge
        if ((challengeText.equals("") || challengeText.length() == 0)) {
          String blankChallengeError = getString(R.string.dialog_blank_challenge_error);
          showErrorDialogue(blankChallengeError);
        }
        // valid challenge
        else {
          CharSequence text;
          long newChallengeId = 0;

          DataBaseAdapter dbAdapter = new DataBaseAdapter(context);
          try {
            dbAdapter.open();
          }
          catch (SQLiteException sqle) {
            Log.e(TAG, sqle.toString());
          }

          try {
            // add the new challenge to the database
            newChallengeId = dbAdapter.addChallenge(challengeText);
          }
          catch (SQLiteException sqle) {
            Log.e(TAG, sqle.toString());
          }

          // challenge was successfully added to the database
          if (newChallengeId > 0) {
            // add the new challenge to the ongoing game, if there is one
            AddToOngoingGame(newChallengeId);
            text = getString(R.string.toast_add_challenge_success);
            mNewChallengeEditText.setText("");
          }
          // challenge was not successfully added to the database
          else {
            Log.w(TAG, getString(R.string.error_database_insert));
            text = getString(R.string.toast_add_challenge_error);
          }

          try {
            dbAdapter.close();
          }
          catch (SQLiteException mSQLException) {
            Log.e(TAG, mSQLException.toString());
          }

          int duration = Toast.LENGTH_SHORT;
          Toast toast = Toast.makeText(context, text, duration);
          toast.show();

          Intent intent = new Intent(getBaseContext(), MyChallengesActivity.class);
          intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
          startActivity(intent);
          finish();
        }
      }
    });
  }


  /**
   * Activity method called when the activity is becoming visible to the user
   */
  @Override
  protected void onStart() {
    super.onStart();

    // attach the text changed listener to the new challenge EditText
    mNewChallengeEditText.addTextChangedListener(challengeCharacterCounterWatcher);
  }


  /**
   * Activity method called when the activity has detected the user's press of the back key
   */
  @Override
  public void onBackPressed() {

    Intent intent = new Intent(this, MyChallengesActivity.class);
    intent.putExtra("reachedByBackPress", true);
    intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
    startActivity(intent);
    finish();
  }


  /**
   * Method that displays an AlertDialog with a given message
   *
   * @param message text which will appear as the AlertDialog message
   */
  private void showErrorDialogue(String message) {

    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
    dialogBuilder.setTitle(
        getString(com.themapples.valentinesday.library.R.string.dialog_title_error));
    dialogBuilder.setIcon(com.themapples.valentinesday.library.R.drawable.heart);
    dialogBuilder.setMessage(message);
    dialogBuilder.setCancelable(false);

    dialogBuilder.setPositiveButton(
        getString(com.themapples.valentinesday.library.R.string.dialog_button_ok),
        new DialogInterface.OnClickListener() {
      public void onClick(DialogInterface dialog, int id) {
        dialog.dismiss();
      }
    });

    AlertDialog emptyChallengeAlertDialogue = dialogBuilder.create();
    emptyChallengeAlertDialogue.show();
  }

  /**
   * TextWatcher method which is called when value of the new challenge EditText is changed
   */
  private final TextWatcher challengeCharacterCounterWatcher = new TextWatcher() {

    /**
     * Abstract method beforeTextChanged must be implemented to create a TextWatcher
     *
     * @param  s initial text whose content will changed
     * @param  start character position where the initial text will be changed
     * @param  count number of characters whose content will be changed in the initial text
     * @param  after length of the new text which will replace the old one
     */
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    /**
     * Method which updates the character counter when the value of the EditText has changed
     *
     * @param  s new text whose content has changed
     * @param  start character position where the new text has changed
     * @param  before length of the initial text which was replace by the new one
     * @param  count number of characters whose content has changed in the new text
     */
    public void onTextChanged(CharSequence s, int start, int before, int count) {
      mChallengeCharacterCounter.setText(
          getString(com.themapples.valentinesday.library.R.string.character_counter_label) +
          String.valueOf(MAX_CHALLENGES_LENGTH - s.length()));
    }

    /**
     * Abstract method afterTextChanged must be implemented in implement a TextWatcher
     *
     * @param  s text whose content has changed
     */
    public void afterTextChanged(Editable s) {
    }
  };


  /**
   * Method that adds the id of the newly added challenge to the game currently in progress
   *
   * @param trueChallengeId the id of the challenge from the available challenges list
   */
  private void AddToOngoingGame(long trueChallengeId) {

    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
    Boolean gameExists = sharedPrefs.getBoolean("gameExists", false);

    // a game is currently in progress
    if (gameExists) {
      String remainingChallengesList = sharedPrefs.getString("remainingChallengesList", "");
      remainingChallengesList = remainingChallengesList + trueChallengeId + " ";
      sharedPrefs.edit().putString("remainingChallengesList", remainingChallengesList).apply();
    }
  }

}
