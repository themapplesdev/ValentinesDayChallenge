/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.themapples.valentinesday.challenge.premium;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.SQLException;
import android.database.sqlite.SQLiteException;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.themapples.valentinesday.library.DataBaseAdapter;

import java.util.ArrayList;


/**
 * Activity which displays the list of all custom challenges
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class MyChallengesActivity extends ListActivity {

  private MediaPlayer mUtilityActivitySound;
  private Boolean mSoundOn;
  private Boolean mActivityStopped;
  private LinearLayout mProgressbarView;
  private ListView mListView;
  private AlertDialog mSelectionListDialog;
  private AlertDialog mDeleteAlertDialog;
  private TextView mEmptyListMessageTextView;
  private ArrayAdapter<String> mArrayAdapter;
  private final int DEFAULT_TOTAL_CHALLENGES_PREMIUM = 60; // number of records in challenges table
  private static final String TAG = "MyChallengesActivity";


  /**
   * Activity method called when the activity is first created
   */
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_my_challenges);

    mActivityStopped = false;
    mProgressbarView = (LinearLayout) findViewById(R.id.progressbarView);

    Context context = getApplicationContext();
    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
    mSoundOn = sharedPrefs.getBoolean("soundOn", true);
    mEmptyListMessageTextView = (TextView) findViewById(R.id.emptyListMessageTextView);

    // set custom font to title
    TextView challengesTitleTextView = (TextView) findViewById(R.id.challengesTitleTextView);
    Typeface customFont = Typeface.createFromAsset(getAssets(), "ArchitectsDaughter.ttf");
    challengesTitleTextView.setTypeface(customFont);

    mListView = getListView();

    DataBaseAdapter dbAdapter = new DataBaseAdapter(context);
    try {
      dbAdapter.open();
    }
    catch (SQLiteException sqle) {
      Log.e(TAG, sqle.toString());
    }

    // get the list of all custom challenges from the database
    ArrayList<String> myChallenges = dbAdapter.getMyChallenges();

    try {
      dbAdapter.close();
    }
    catch (SQLiteException sqle) {
      Log.e(TAG, sqle.toString());
    }

    // there are custom challenges
    if (myChallenges != null) {

      mEmptyListMessageTextView.setVisibility(View.GONE);

      // populate the ListView with the custom challenges
      mArrayAdapter = new ArrayAdapter<>(this, R.layout.single_listview_row, myChallenges);
      setListAdapter(mArrayAdapter);

      // asynchronously display the progress bar and wait for the ListView to load
      new AsynchronousTask().execute();
      getListView().setTextFilterEnabled(true);
    }
    // no custom challenges were found
    else {

      // hide the empty ListView layout
      mListView.setVisibility(View.GONE);
      // display the message saying that no custom challenges were found
      mEmptyListMessageTextView.setVisibility(View.VISIBLE);
      // hide the progress bar
      mProgressbarView.setVisibility(View.GONE);
    }

    ImageButton addChallengeButton = (ImageButton) findViewById(R.id.addChallengeButton);
    addChallengeButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {

        Intent intent = new Intent(getBaseContext(), AddChallengeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
      }
    });

    // set up a click listener on the ListView items
    mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> adapterView,
                              View view, int itemPosition, long challengeId) {
        onListItemClick(challengeId);
      }
    });

    // set up a long click listener on the ListView items
    mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

      public boolean onItemLongClick(AdapterView<?> adapterView,
                                     View view, int itemPosition, long challengeId) {
        return onLongListItemClick(view, challengeId);
      }
    });
  }


  /**
   * Activity method called when the system is about to start resuming a previous activity
   */
  @Override
  protected void onPause() {
    super.onPause();

    mActivityStopped = true;

    if (mDeleteAlertDialog != null) {
      mDeleteAlertDialog.dismiss();
    }

    if (mSelectionListDialog != null) {
      mSelectionListDialog.dismiss();
    }

    if(mSoundOn) {
      if (mUtilityActivitySound != null) {
        if (mUtilityActivitySound.isPlaying() || mUtilityActivitySound.isLooping()) {
          mUtilityActivitySound.stop();
        }
        mUtilityActivitySound.reset();
        mUtilityActivitySound.release();
        mUtilityActivitySound = null;
      }
    }
  }


  /**
   * Activity method called when the activity has detected the user's press of the back key
   */
  @Override
  public void onBackPressed() {

    Intent intent = new Intent(this, MenuActivity.class);
    intent.putExtra("reachedByBackPress", true);
    intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
    startActivity(intent);
    finish();
  }

  /**
   * Method that updates the ListView data when an item has changed
   */
  private void updateData() {

    DataBaseAdapter dbAdapter = new DataBaseAdapter(this);
    try {
      dbAdapter.open();
    }
    catch (SQLiteException sqle) {
      Log.e(TAG, sqle.toString());
    }

    // get the new list of all custom challenges
    ArrayList<String> myChallenges = dbAdapter.getMyChallenges();

    try {
      dbAdapter.close();
    }
    catch (SQLiteException sqle) {
      Log.e(TAG, sqle.toString());
    }

    // there are custom challenges
    if (myChallenges != null) {

      mEmptyListMessageTextView.setVisibility(View.GONE);

      // populate the ListView with the custom challenges
      mArrayAdapter = new ArrayAdapter<>(this, R.layout.single_listview_row, myChallenges);
      setListAdapter(mArrayAdapter);

      // asynchronously display the progress bar and wait for the ListView to load
      new AsynchronousTask().execute();
      getListView().setTextFilterEnabled(true);
    }
    // no custom challenges were found
    else {
      // display the message saying that no custom challenges were found
      mListView.setVisibility(View.GONE);

      // hide the progress bar
      mEmptyListMessageTextView.setVisibility(View.VISIBLE);
    }

    // notify the ArrayAdapter with the new changes
    mArrayAdapter.notifyDataSetChanged();
  }


  /**
   * Asynchronous task that puts the main thread to sleep while it display the progress bar
   */
  private class AsynchronousTask extends AsyncTask<String, Integer, Boolean> {

    /**
     *  Method invoked on the UI thread before the task is executed.
     */
    @Override
    protected void onPreExecute() {
      super.onPreExecute();

      if(!mActivityStopped) {
        mProgressbarView.setVisibility(View.VISIBLE);
        mListView.setVisibility(View.GONE);
      }
    }

    /**
     * Method invoked on the background thread immediately after onPreExecute finishes executing
     *
     * @param params the parameters sent to the task upon execution
     */
    @Override
    protected Boolean doInBackground(String... params) {

      if(!mActivityStopped) {
        try {
          Thread.sleep(1750);
        }
        catch (Exception e) {
          e.printStackTrace();
        }
      }

      return null;
    }

    /**
     * Method invoked on the UI thread after the background computation finishes
     *
     * @param result the result of the background computation
     */
    @Override
    protected void onPostExecute(Boolean result) {
      super.onPostExecute(result);

      if (!mActivityStopped) {
        if (mSoundOn) {
          mUtilityActivitySound = MediaPlayer.create(getBaseContext(),
              com.themapples.valentinesday.library.R.raw.utility_activity_sound);
          PlaySound(mUtilityActivitySound, false);
        }

        // display the progress bar
        mProgressbarView.setVisibility(View.GONE);
        mListView.setVisibility(View.VISIBLE);

        // notify the ArrayAdapter with the new changes
        mArrayAdapter.notifyDataSetChanged();
      }
    }
  }


  /**
   * Method that handles a normal click on a ListView item
   *
   * @param challengeId id of the clicked item
   */
  private void onListItemClick(long challengeId) {

    // get the challenge row number of the clicked item (which is not the same as the challenge id)
    final long challengeRow = DEFAULT_TOTAL_CHALLENGES_PREMIUM + challengeId;

    Intent intent = new Intent(getBaseContext(), EditChallengeActivity.class);
    intent.putExtra("challengeRow", challengeRow);
    intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
    startActivity(intent);
    finish();
  }


  /**
   * Method that handles a long click on a ListView item
   *
   * @param view view where the long click occurred
   * @param challengeId id of the clicked item
   * @return true
   */
  private boolean onLongListItemClick(View view, long challengeId) {

    final long challengeRow = DEFAULT_TOTAL_CHALLENGES_PREMIUM + challengeId;
    String selectedItemContent =
        ((TextView) view.findViewById(R.id.single_listview_row)).getText().toString();

    CharSequence[] items = {"edit", "delete"};
    final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MyChallengesActivity.this);
    dialogBuilder.setTitle(selectedItemContent);
    dialogBuilder.setItems(items, new DialogInterface.OnClickListener() {
      public void onClick(DialogInterface dialog, int which) {

        //which is 0, meaning that the edit button wes selected
        if (which == 0) {
          dialog.dismiss();
          Intent intent = new Intent(getBaseContext(), EditChallengeActivity.class);
          intent.putExtra("challengeRow", challengeRow);
          intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
          startActivity(intent);
          finish();
        }
        else {
          //which is 1, meaning that the delete button was selected
          if (which == 1) {
            // AlertDialog asking the user for confirmation before deleting a challenge
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MyChallengesActivity.this);
            dialogBuilder.setTitle(
                getString(com.themapples.valentinesday.library.R.string.dialog_title_warning));
            dialogBuilder.setIcon(com.themapples.valentinesday.library.R.drawable.heart);
            dialogBuilder.setMessage(getResources().
                getString(R.string.dialog_warning_delete_challenge));
            dialogBuilder.setCancelable(false);
            dialogBuilder.setPositiveButton(
                com.themapples.valentinesday.library.R.string.dialog_button_yes,
                new DialogInterface.OnClickListener() {
              public void onClick(DialogInterface dialog, int id) {

                dialog.dismiss();
                Context context = MyChallengesActivity.this;

                CharSequence text = "";
                String trueChallengeId = "";

                DataBaseAdapter dbAdapter = new DataBaseAdapter(context);
                try {
                  dbAdapter.open();
                }
                catch (SQLiteException sqle) {
                  Log.e(TAG, sqle.toString());
                }

                try {
                  // get the true id of the challenge, based on its row number
                  trueChallengeId = dbAdapter.getNthChallengeId((int) challengeRow);
                }
                catch (SQLiteException sqle) {
                  Log.e(TAG, sqle.toString());
                }

                try {
                  // challenge was successfully deleted from the challenges table
                  if (dbAdapter.deleteChallenge(trueChallengeId)) {

                    // delete the id of the challenge from the ongoing game, if there is one
                    RemoveFromOngoingGame(trueChallengeId);
                    text = getString(R.string.toast_delete_challenge_success);
                  }
                  // challenge was not successfully deleted from the challenges table
                  else {
                    text = getString(R.string.toast_delete_challenge_error);
                  }
                }
                catch (SQLiteException sqle) {
                  Log.e(TAG, sqle.toString());
                }

                try {
                  dbAdapter.close();
                }
                catch (SQLException mSQLException) {
                  Log.e(TAG, mSQLException.toString());
                }

                // call the data update method to rebuild the ListView
                updateData();

                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
              }
            });

            dialogBuilder.setNegativeButton(
                com.themapples.valentinesday.library.R.string.dialog_button_no,
                new DialogInterface.OnClickListener() {
              public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
              }
            });

            mDeleteAlertDialog = dialogBuilder.create();
            mDeleteAlertDialog.show();
          }
        }
      }
    });

    mSelectionListDialog = dialogBuilder.create();
    mSelectionListDialog.show();

    return true;
  }


  /**
   * Method that removes the id of the deleted challenge from the game currently in progress
   *
   * @param idToRemove the id of the challenge which is to be removed from the game
   */
  private void RemoveFromOngoingGame(String idToRemove) {

    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
    Boolean gameExists = sharedPrefs.getBoolean("gameExists", false);

    // a game is currently in progress
    if (gameExists) {
      String remainingChallengesList = sharedPrefs.getString("remainingChallengesList", "");
      remainingChallengesList = remainingChallengesList.replace(idToRemove + " ", "");
      sharedPrefs.edit().putString("remainingChallengesList", remainingChallengesList).apply();
    }
  }


  /**
   * Method that plays a sound resource
   *
   * @param mediaPlayer the MediaPlayer object to be played
   * @param playInLoop whether the sound is to be played once or in a continuous loop
   */
  public void PlaySound(MediaPlayer mediaPlayer, Boolean playInLoop) {

    if (mediaPlayer.isPlaying() || mediaPlayer.isLooping()) {
      mediaPlayer.pause();
    }

    if (playInLoop) {
      mediaPlayer.setLooping(true);
    }
    else {
      mediaPlayer.setLooping(false);
    }

    mediaPlayer.start();
  }

}