/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.themapples.valentinesday.challenge.free;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


/**
 * Activity which offers the user the controls to customize the app and the game
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class SettingsActivity extends Activity {

  private CheckBox mStartupInfoCheckBox;
  private CheckBox mSoundOnCheckBox;
  private CheckBox mMusicOnCheckBox;
  private RadioGroup mRadioGroup;
  private int mTotalRounds;
  private Boolean soundOnChecked;
  private Boolean musicOnChecked;
  private Boolean showInfoChecked;

  /**
   * Activity method called when the activity is first created
   */
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_settings);

    final int DEFAULT_TOTAL_ROUNDS_FREE = 10;
    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
    mTotalRounds = sharedPrefs.getInt("totalRounds", DEFAULT_TOTAL_ROUNDS_FREE);
    mRadioGroup = (RadioGroup) findViewById(R.id.turnsRadioGroup);

    RadioButton checkedRadio;
    switch (mTotalRounds) {
      case 5: checkedRadio = (RadioButton) findViewById(R.id.radio0); break;
      case 10: checkedRadio = (RadioButton) findViewById(R.id.radio1); break;
      case 15: checkedRadio = (RadioButton) findViewById(R.id.radio2); break;
      default: checkedRadio = (RadioButton) findViewById(R.id.radio1); break;
    }
    checkedRadio.setChecked(true);
    // set custom font to title
    TextView settingsTitleTextView = (TextView) findViewById(R.id.settingsTitleTextView);
    Typeface customFont = Typeface.createFromAsset(getAssets(), "ArchitectsDaughter.ttf");
    settingsTitleTextView.setTypeface(customFont);
    // get the current state of the settings
    soundOnChecked = sharedPrefs.getBoolean("soundOn", true);
    musicOnChecked = sharedPrefs.getBoolean("musicOn", true);
    showInfoChecked = sharedPrefs.getBoolean("showInfo", true);

    mSoundOnCheckBox = (CheckBox) findViewById(R.id.soundOnCheckBox);
    mSoundOnCheckBox.setChecked(soundOnChecked);
    mSoundOnCheckBox.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v) {
        soundOnChecked = mSoundOnCheckBox.isChecked();
      }
    });

    mMusicOnCheckBox = (CheckBox) findViewById(R.id.musicOnCheckBox);
    mMusicOnCheckBox.setChecked(musicOnChecked);
    mMusicOnCheckBox.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v) {
        musicOnChecked = mMusicOnCheckBox.isChecked();
      }
    });

    mStartupInfoCheckBox = (CheckBox) findViewById(R.id.startupInfoCheckBox);
    mStartupInfoCheckBox.setChecked(showInfoChecked);
    mStartupInfoCheckBox.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View v) {
        showInfoChecked = mStartupInfoCheckBox.isChecked();
      }
    });
  }


  /**
   * Activity method called when the activity has detected the user's press of the back key
   */
  @Override
  public void onBackPressed() {

    /* the settings are not saved in real time as the user checks/un-checks them,
    but upon pressing the back button and returning to the menu
     */
    String selected = null;
    int newTotalRounds = 0;
    Context context = getApplicationContext();

    String rounds5 = getString(com.themapples.valentinesday.library.R.string.settings_rounds_5);
    String rounds10 = getString(com.themapples.valentinesday.library.R.string.settings_rounds_10);
    String rounds15 = getString(com.themapples.valentinesday.library.R.string.settings_rounds_15);
    // the present configuration is saved
    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
    sharedPrefs.edit().putBoolean("soundOn", soundOnChecked).apply();
    sharedPrefs.edit().putBoolean("musicOn", musicOnChecked).apply();
    sharedPrefs.edit().putBoolean("showInfo", showInfoChecked).apply();

    // get the selected radio button for the number of rounds per game
    if (mRadioGroup.getCheckedRadioButtonId() != -1) {
      int id = mRadioGroup.getCheckedRadioButtonId();
      View radioButtonView = mRadioGroup.findViewById(id);
      int radioId = mRadioGroup.indexOfChild(radioButtonView);
      RadioButton radioButton = (RadioButton) mRadioGroup.getChildAt(radioId);
      selected = (String) radioButton.getText();
    }

    // save the selected total rounds
    if ((selected != null) && (selected.equals(rounds5) || selected.equals(rounds10) ||
        selected.equals(rounds15))) {
      String[] splitSelected = selected.split("\\s+");
      newTotalRounds = Integer.parseInt(splitSelected[0]);
      sharedPrefs.edit().putInt("totalRounds", newTotalRounds).apply();
    }

    // compare the previous settings to the current ones, to detect changes
    if (mTotalRounds != newTotalRounds) {
      CharSequence text =
          getString(com.themapples.valentinesday.library.R.string.toast_settings_changed);
      int duration = Toast.LENGTH_SHORT;
      Toast toast = Toast.makeText(context, text, duration);
      toast.show();
    }

    Intent intent = new Intent(this, MenuActivity.class);
    intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
    startActivity(intent);
    finish();
  }
}
