/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.themapples.valentinesday.library;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


/**
 * Activity which displays the final outcome of the game
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class OutcomeActivity extends Activity {

  private Boolean mMusicOn;
  private Boolean mSoundOn;
  private Boolean mIsRated;
  private SharedPreferences mSharedPrefs;
  private AlertDialog mRateItDialog;
  private String mNamePlayer1;
  private String mNamePlayer2;
  //private String facebookPostDescription;
  private int mScorePlayer1;
  private int mScorePlayer2;
  private Handler mHandlerLastSound = new Handler();
  private Handler mHandlerDelayed = new Handler();
  private MediaPlayer mChallengeDoneSound;
  private MediaPlayer mChallengeSkipSound;
  private MediaPlayer mOutcomeVictoryMusic;
  private MediaPlayer mOutcomeDrawMusic;
  private Boolean mResultIsDraw;
  //private UiLifecycleHelper uiHelper;
  private static final String TAG = "OutcomeActivity";

  /*
  private Session.StatusCallback callback = new Session.StatusCallback() {

    @Override
    public void call(Session session, SessionState state, Exception exception) {

      if (state.isOpened()) {
        publishFeedDialog();
      }
    }
  };
  */

  /**
   * Activity method called when the activity is first created
   */
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_outcome);

    mSharedPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
    // the OutcomeActivity cannot be resumed once the player has returned to the main menu
    mSharedPrefs.edit().putString("lastGameActivity", "").apply();
    mSharedPrefs.edit().putString("remainingChallengesList", "").apply();

    mMusicOn = mSharedPrefs.getBoolean("musicOn", true);
    mSoundOn = mSharedPrefs.getBoolean("soundOn", true);

    Bundle extras = getIntent().getExtras();
    // determine if OutcomeActivity was reached through the "skip" button or the "done" button
    Boolean mChallengeDone = (extras != null) && extras.getBoolean("challengeDone");

    if(mSoundOn) {
      if (mChallengeDone) {
        mChallengeDoneSound = MediaPlayer.create(
            getBaseContext(), com.themapples.valentinesday.library.R.raw.challenge_done_sound);
        PlaySound(mChallengeDoneSound, false);
      }
      else {
        mChallengeSkipSound = MediaPlayer.create(
            getBaseContext(),com.themapples.valentinesday.library.R.raw.challenge_skip_sound);
        PlaySound(mChallengeSkipSound, false);
      }
    }

    mIsRated = mSharedPrefs.getBoolean("isRated", false);
    Boolean gameExists = mSharedPrefs.getBoolean("gameExists", false);

    // a valid game is in progress
    if(gameExists) {
      // get game parameters and its current state
      mNamePlayer1 = mSharedPrefs.getString("namePlayer1", "");
      mNamePlayer2 = mSharedPrefs.getString("namePlayer2", "");
      mScorePlayer1 = mSharedPrefs.getInt("scorePlayer1", 0);
      mScorePlayer2 = mSharedPrefs.getInt("scorePlayer2", 0);
    }
    else {
      // this activity should not never have been reached without an ongoing valid game
      Log.wtf(TAG, getString(R.string.error_should_not_be_here_at_all));
    }

    final Context context = getApplicationContext();
    // delayed display of the rate-it dialogue and play the outcome music
    mHandlerDelayed.postDelayed(new Runnable() {

      @Override
      public void run() {
        // the user hasn't already rated the application
        if(!mIsRated) {
          if(mRateItDialog != null) {
            mRateItDialog.dismiss();
          }

          AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(OutcomeActivity.this);
          dialogBuilder.setTitle(getString(R.string.dialog_title_rate_it));
          dialogBuilder.setIcon(R.drawable.heart);	// five stars icon!
          dialogBuilder.setMessage(getResources().getString(R.string.dialog_rating_message));
          dialogBuilder.setCancelable(false);

          dialogBuilder.setNegativeButton(getString(R.string.dialog_button_rate_it),
              new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {

                  dialog.dismiss();
                  Uri uri = Uri.parse("market://details?id=" + context.getPackageName());

                  // open the Google market application page
                  try {
                    Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
                    goToMarket.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mSharedPrefs.edit().putBoolean("isRated", true).apply();
                    context.startActivity(goToMarket);
                  }
                  catch(ActivityNotFoundException ignore) {
                    CharSequence marketErrorText = getResources().getString(
                        R.string.dialog_rating_error);
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, marketErrorText, duration);
                    toast.show();
                  }
                }
              });

          dialogBuilder.setPositiveButton(getString(R.string.dialog_button_later),
              new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                  dialog.dismiss();
                  mSharedPrefs.edit().putBoolean("isRated", false).apply();
                }
              });

          mRateItDialog = dialogBuilder.create();
          mRateItDialog.show();
        }
      }
    }, 2000);

    /*
    //configure the Facebook UiLifecycleHelper
    uiHelper = new UiLifecycleHelper(this, callback);
    uiHelper.onCreate(savedInstanceState);

    // Facebook button for share/post
    ImageButton facebookButton = (ImageButton) findViewById(com.themapples.valentinesday.library.R.id.facebookButton);
    facebookButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {

        // FacebookDialog can be displayed, the Facebook app is installed on this device
        if (FacebookDialog.canPresentShareDialog(getApplicationContext(),
            FacebookDialog.ShareDialogFeature.SHARE_DIALOG)) {
          // Publish the post using the Share Dialog
          FacebookDialog shareDialog = new FacebookDialog.ShareDialogBuilder(OutcomeActivity.this)
              .setLink(getResources().getString(R.string.post_facebook_hyperlink))
              .setName(getResources().getString(R.string.post_facebook_title))
              .setCaption(getResources().getString(R.string.post_facebook_caption))
              .setDescription(facebookPostDescription)
              .setPicture(getResources().getString(R.string.post_facebook_imagelink))
              .build();
          uiHelper.trackPendingDialogCall(shareDialog.present());
        }
        // fallback - publish the post using the Feed Dialog
        else {
          // a session does not exist
          if (Session.getActiveSession() == null || !Session.getActiveSession().isOpened()) {
            // create a new session
            Session.openActiveSession(OutcomeActivity.this, true, callback);
          }
          // a session already exists
          else {
            publishFeedDialog();
          }
        }
      }
    });
    */

    String endgameOutcome;
    String winnerName = "";
    String loserName = "";
    mResultIsDraw = false;
    int scoreDifference = 0;
    ImageView outcomeImageView = (ImageView)findViewById(R.id.outcomeImageLayout);

    // player1 wins
    if(mScorePlayer1 > mScorePlayer2) {
      endgameOutcome = mNamePlayer1 + " " + getString(R.string.layout_outcome_win_message);
      /*facebookPostDescription = mNamePlayer1 + " just bested " + mNamePlayer2 +
          " at Valentine's Day Challenge! " + getString(R.string.layout_outcome_win_message);*/
      outcomeImageView.setImageResource(R.drawable.outcome_win);
      scoreDifference = mScorePlayer1 - mScorePlayer2;
      winnerName = mNamePlayer1;
      loserName = mNamePlayer2;
    }
    else {
      // player2 wins
      if(mScorePlayer1 < mScorePlayer2) {
        endgameOutcome = mNamePlayer2 + " " + getString(R.string.layout_outcome_win_message);
        /*facebookPostDescription = mNamePlayer2 + " just bested " + mNamePlayer1 +
            " at Valentine's Day Challenge! " + getString(R.string.post_facebook_description);*/
        outcomeImageView.setImageResource(R.drawable.outcome_win);
        scoreDifference = mScorePlayer2 - mScorePlayer1;
        winnerName = mNamePlayer2;
        loserName = mNamePlayer1;
      }
      // it's a draw (tie!)
      else {
        endgameOutcome = getString(R.string.layout_outcome_draw_message);
        /*facebookPostDescription = mNamePlayer1 + " and " + mNamePlayer2 +
            " scored a tie at Valentine's Day Challenge!";*/
        mResultIsDraw = true;
        outcomeImageView.setImageResource(R.drawable.outcome_tie);
      }
    }

    String finalChallenge;
    // based on the score difference, pick the text of the final challenges
    switch(scoreDifference) {
      case 0: finalChallenge = getString(R.string.layout_outcome_final_challenge_draw);break;
      case 1: finalChallenge = getString(R.string.layout_outcome_final_challenge_dif1);break;
      case 2: finalChallenge = getString(R.string.layout_outcome_final_challenge_dif2);break;
      case 3: finalChallenge = getString(R.string.layout_outcome_final_challenge_dif3);break;
      case 4: finalChallenge = getString(R.string.layout_outcome_final_challenge_dif4);break;
      case 5: finalChallenge = getString(R.string.layout_outcome_final_challenge_dif5);break;
      default: finalChallenge = getString(R.string.layout_outcome_final_challenge_dif5);break;
    }

    // replace the names placeholders with the actual players' names
    finalChallenge = finalChallenge.replaceAll("%winner%", winnerName);
    finalChallenge = finalChallenge.replaceAll("%loser%", loserName);

    // load custom font
    Typeface customFont = Typeface.createFromAsset(getAssets(), "ArchitectsDaughter.ttf");

    TextView outcomeTitleTextView = (TextView)findViewById(R.id.outcomeTitleTextView);
    outcomeTitleTextView.setText(endgameOutcome);

    TextView finalChallengeTextView = (TextView)findViewById(R.id.finalChallengeTextView);
    finalChallengeTextView.setText(finalChallenge);
    finalChallengeTextView.setMovementMethod(new ScrollingMovementMethod());

    outcomeTitleTextView.setTypeface(customFont);
    finalChallengeTextView.setTypeface(customFont);

    TextView outcomePlayerScore1TextView =
        (TextView)findViewById(R.id.outcomePlayerScore1TextView);
    outcomePlayerScore1TextView.setText(mNamePlayer1 + ": " + mScorePlayer1);

    TextView outcomePlayerScore2TextView =
        (TextView)findViewById(R.id.outcomePlayerScore2TextView);
    outcomePlayerScore2TextView.setText(mNamePlayer2 + ": " + mScorePlayer2);

    ImageButton menuButton = (ImageButton) findViewById(R.id.menuButton);
    menuButton.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View view) {

        if(mRateItDialog != null) {
          mRateItDialog.dismiss();
        }

        // a game in progress no longer exists when returning to the main menu
        mSharedPrefs.edit().putBoolean("gameExists", false).apply();

        try {
          /* since project classes are not visible in libraries,
          reflection is used to access the application menu */
          Intent intent = new Intent(getBaseContext(),
              Class.forName(getApplicationContext().getPackageName() + ".MenuActivity"));
          intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
          startActivity(intent);
        }
        catch (ClassNotFoundException e) {
          e.printStackTrace();
        }

        finish();
      }
    });
  }


  /**
   * Activity method called when the activity has detected the user's press of the back key
   */
  @Override
  public void onBackPressed() {

    // save the game parameters when activity is not visible anymore
    mSharedPrefs.edit().putBoolean("gameExists", false).apply();
    mSharedPrefs.edit().putString("activePlayer", "").apply();
    mSharedPrefs.edit().putString("inactivePlayer", "").apply();
    mSharedPrefs.edit().putString("namePlayer1", "").apply();
    mSharedPrefs.edit().putString("namePlayer2", "").apply();
    mSharedPrefs.edit().putInt("scorePlayer1", 0).apply();
    mSharedPrefs.edit().putInt("scorePlayer2", 0).apply();
    mSharedPrefs.edit().putInt("turnNumber", 0).apply();
    mSharedPrefs.edit().putInt("gameTotalRounds", 0).apply();
    mSharedPrefs.edit().putString("remainingChallengesList", "").apply();

    try {
      /* since project classes are not visible in libraries,
      reflection is used to access the application menu */
      Intent intent = new Intent(getBaseContext(),
          Class.forName(getApplicationContext().getPackageName() + ".MenuActivity"));
      intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
      startActivity(intent);
      finish();
    }
    catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
  }


  /**
   * Activity method called when the activity is becoming visible to the user
   */
  @Override
  protected void onStart() {
    super.onStart();

    if(mRateItDialog != null) {
      mRateItDialog.dismiss();
    }

    if(mMusicOn) {
      mHandlerLastSound.postDelayed(new Runnable() {
        @Override
        public void run() {
          if (mResultIsDraw) {
            mOutcomeDrawMusic = MediaPlayer.create(
                getBaseContext(), com.themapples.valentinesday.library.R.raw.outcome_draw_music);
            PlaySound(mOutcomeDrawMusic, true);
          }
          else {
            mOutcomeVictoryMusic = MediaPlayer.create(
                getBaseContext(), com.themapples.valentinesday.library.R.raw.outcome_victory_music);
            PlaySound(mOutcomeVictoryMusic, true);
          }
        }
      }, 750);
    }
  }


  /**
   * Activity method called when the system is about to start resuming a previous activity
   */
  @Override
  protected void onPause() {
    super.onPause();

    /*
    uiHelper.onDestroy();   // or onPause() here?
    */

    // de-register the handlers
    mHandlerDelayed.removeCallbacksAndMessages(null);
    mHandlerLastSound.removeCallbacksAndMessages(null);

    if (mRateItDialog != null) {
      mRateItDialog.dismiss();
    }

    if(mSoundOn) {
      if (mChallengeDoneSound != null) {
        if (mChallengeDoneSound.isPlaying() || mChallengeDoneSound.isLooping()) {
          mChallengeDoneSound.stop();
        }
        mChallengeDoneSound.reset();
        mChallengeDoneSound.release();
        mChallengeDoneSound = null;
      }

      if (mChallengeSkipSound != null) {
        if (mChallengeSkipSound.isPlaying() || mChallengeSkipSound.isLooping()) {
          mChallengeSkipSound.stop();
        }
        mChallengeSkipSound.reset();
        mChallengeSkipSound.release();
        mChallengeSkipSound = null;
      }
    }

    if(mMusicOn) {
      if (mOutcomeVictoryMusic != null) {
        if (mOutcomeVictoryMusic.isPlaying() || mOutcomeVictoryMusic.isLooping()) {
          mOutcomeVictoryMusic.stop();
        }
        mOutcomeVictoryMusic.reset();
        mOutcomeVictoryMusic.release();
        mOutcomeVictoryMusic = null;
      }

      if (mOutcomeDrawMusic != null) {
        if (mOutcomeDrawMusic.isPlaying() || mOutcomeDrawMusic.isLooping()) {
          mOutcomeDrawMusic.stop();
        }
        mOutcomeDrawMusic.reset();
        mOutcomeDrawMusic.release();
        mOutcomeDrawMusic = null;
      }
    }
  }


  /**
   * Activity method called when the activity will start interacting with the user
   */
  @Override
  protected void onResume() {
    super.onResume();

    /*
    uiHelper.onResume();
    */
  }


  /**
   * The final call received before your activity is destroyed
   */
  @Override
  public void onDestroy() {
    super.onDestroy();

    /*
    uiHelper.onDestroy();
    */
  }


  /**
   * Called before placing the activity in such a background state
   *
   * @param outState Bundle in which the saved states are placed
   */
  /*
  @Override
  protected void onSaveInstanceState(@NonNull Bundle outState) {
    super.onSaveInstanceState(outState);
    uiHelper.onSaveInstanceState(outState);
  }
  */

  /**
   * Callback received as the result data of an Intent object
   *
   * @param requestCode the request which started the activity
   * @param resultCode  the result code returned by the request
   * @param data  additional data of the result
   */
  /*
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);

    Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);

    uiHelper.onActivityResult(requestCode, resultCode, data, new FacebookDialog.Callback() {
      @Override
      public void onError(FacebookDialog.PendingCall pendingCall, Exception error, Bundle data) {
      }

      @Override
      public void onComplete(FacebookDialog.PendingCall pendingCall, Bundle data) {
      }
    });
  }
  */

  /**
   * Display a FeedDialog for publishing the post to Facebook (when Facebook app not installed)
   */
  /*
  private void publishFeedDialog() {

    Bundle params = new Bundle();
    params.putString("name", getResources().getString(R.string.post_facebook_title));
    params.putString("caption", getResources().getString(R.string.post_facebook_caption));
    params.putString("description", facebookPostDescription);
    params.putString("link", getResources().getString(R.string.post_facebook_hyperlink));
    params.putString("picture", getResources().getString(R.string.post_facebook_imagelink));

    WebDialog feedDialog = (
        new WebDialog.FeedDialogBuilder(OutcomeActivity.this,
            Session.getActiveSession(),
            params))
        .setOnCompleteListener(new WebDialog.OnCompleteListener() {

          @Override
          public void onComplete(Bundle values, FacebookException error) {
            // post successfully completed
            if (error == null) {
              final String postId = values.getString("post_id");
              // post succeeded
              if (postId != null) {
                Toast.makeText(OutcomeActivity.this,
                    getResources().getString(R.string.post_facebook_success),
                    Toast.LENGTH_SHORT).show();
              }
              else {
                // user clicked the "cancel" button
                Toast.makeText(OutcomeActivity.this,
                    getResources().getString(R.string.post_facebook_cancelled),
                    Toast.LENGTH_SHORT).show();
              }
            }
            // post did not complete
            else {
              if (error instanceof FacebookOperationCanceledException) {
                // user clicked the "x" button
                Toast.makeText(OutcomeActivity.this,
                    getResources().getString(R.string.post_facebook_cancelled),
                    Toast.LENGTH_SHORT).show();
              }
              else {
                // generic error
                Toast.makeText(OutcomeActivity.this,
                    getResources().getString(R.string.post_facebook_error),
                    Toast.LENGTH_SHORT).show();
              }
            }
          }
        })
        .build();
    feedDialog.show();
  }
  */

  /**
   * Method that plays a sound resource
   *
   * @param mediaPlayer the MediaPlayer object to be played
   * @param playInLoop  whether the sound is to be played once or in a continuous loop
   */
  public void PlaySound(MediaPlayer mediaPlayer, Boolean playInLoop) {

    if (mediaPlayer.isPlaying() || mediaPlayer.isLooping()) {
      mediaPlayer.pause();
    }

    if (playInLoop) {
      mediaPlayer.setLooping(true);
    }
    else {
      mediaPlayer.setLooping(false);
    }

    mediaPlayer.start();
  }

}
