/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.themapples.valentinesday.library;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;


/**
 * Class which uses the accelerometer to detect when a shake event occurs
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class ShakeEventListener implements SensorEventListener {

  // minimum movement force
  private static final int MIN_FORCE = 8;

  // minimum times the direction of the shake gesture needs to change
  private static final int MIN_DIRECTION_CHANGE = 3;

  // maximum time between direction changes
  private static final int MAX_PAUSE_BETWEEN_DIRECTION_CHANGE = 200;

  // maximum duration of the shake gesture
  private static final int MAX_TOTAL_DURATION_OF_SHAKE = 400;

  // time when the shake gesture started
  private long mFirstDirectionChangeTime = 0;

  // time when the last shake gesture started
  private long mLastDirectionChangeTime;

  // number of occurred direction changes
  private int mDirectionChangeCount = 0;
  private float mLastX = 0;   // last X position
  private float mLastY = 0;   // last Y position
  private float mLastZ = 0;   // last Z position
  private OnShakeListener mShakeListener;   // shake listener

  /**
   * Interface for the shake gesture, called when a shake gesture is detected
   */
  public interface OnShakeListener {
    void onShake();
  }

  /**
   * Method which registers a new shake listener
   */
  public void setOnShakeListener(OnShakeListener listener) {
    mShakeListener = listener;
  }

  /**
   * Method called when sensor values have changed
   */
  @Override
  public void onSensorChanged(SensorEvent se) {

    // get positional values from the sensor
    float x = se.values[0];
    float y = se.values[1];
    float z = se.values[2];

    // calculate total displacement since the previous position
    float totalMovement = Math.abs(x + y + z - mLastX - mLastY - mLastZ);

    // total displacement qualifies as a valid movement
    if (totalMovement > MIN_FORCE) {

      // get current time
      long now = System.currentTimeMillis();

      // save the time of the first movement
      if (mFirstDirectionChangeTime == 0) {
        mFirstDirectionChangeTime = now;
        mLastDirectionChangeTime = now;
      }

      // check if the last movement was recent enough
      long lastChangeWasAgo = now - mLastDirectionChangeTime;
      if (lastChangeWasAgo < MAX_PAUSE_BETWEEN_DIRECTION_CHANGE) {

        // save last displacement
        mLastDirectionChangeTime = now;
        mDirectionChangeCount++;

        // save previous sensor positional data
        mLastX = x;
        mLastY = y;
        mLastZ = z;

        // enough direction changes detected
        if (mDirectionChangeCount >= MIN_DIRECTION_CHANGE) {

          long totalDuration = now - mFirstDirectionChangeTime;

          // enough total duration of movement
          if (totalDuration < MAX_TOTAL_DURATION_OF_SHAKE) {
            mShakeListener.onShake();
            resetShakeParameters();
          }
        }
      }
      // too much time has passed between consecutive movements
      else {
        resetShakeParameters();
      }
    }
  }

  /**
   * Method which resets the shake parameters to their initial values
   */
  private void resetShakeParameters() {

    mFirstDirectionChangeTime = 0;
    mDirectionChangeCount = 0;
    mLastDirectionChangeTime = 0;
    mLastX = 0;
    mLastY = 0;
    mLastZ = 0;
  }


  /**
   * Abstract method must be implemented in order to extend SensorEventListener
   */
  @Override
  public void onAccuracyChanged(Sensor sensor, int accuracy) {
  }

}