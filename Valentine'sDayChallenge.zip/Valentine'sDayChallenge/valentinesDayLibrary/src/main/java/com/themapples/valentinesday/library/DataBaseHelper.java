/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.themapples.valentinesday.library;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


/**
 * Class for copying a prebuilt database from apk to the internal storage
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class DataBaseHelper extends SQLiteOpenHelper {

	private static final String TAG = "DataBaseHelper";
	private static final String DB_NAME = "ThemApples.ValentinesDay"; // database name
  private static String DB_PATH = ""; // path to the pre-application database
	private SQLiteDatabase mDataBase;
  private final Context mContext;

  /**
   * Class constructor
   */
	public DataBaseHelper(Context context) {
    super(context, DB_NAME, null, 1);   // parameter "1" specifies the database version

    DB_PATH = context.getApplicationInfo().dataDir + "/databases/";
    this.mContext = context;
	}


    /**
     * Method that creates the new database
     *
     * @throws IOException if the database does not exist and copying it from assets failed
     */
	public void createDataBase() throws IOException {

    // unless the database already exists, copy it from assets
    boolean mDataBaseExists = checkDataBase();
    if(!mDataBaseExists) {
      SQLiteDatabase db = this.getReadableDatabase();
      if (db.isOpen()) {
        db.close();
      }

      try {
        copyDataBase();
      }
      catch (IOException e) {
        Log.e(TAG, e.toString());
        throw new RuntimeException(e);
      }
    }
	}


  /**
   * Method that checks if the database exists at the designated path in the device storage
   *
   * @return whether the database exists or not
   */
  public boolean checkDataBase() {

    File dbFile = new File(DB_PATH + DB_NAME);
    return dbFile.exists();
  }


  /**
   * Method that copies the database from assets to the internal storage of the device
   *
   * @throws IOException if copying the database failed
   */
  private void copyDataBase() throws IOException {

    InputStream mInput = mContext.getAssets().open(DB_NAME);
    String outFileName = DB_PATH + DB_NAME;
    OutputStream mOutput = new FileOutputStream(outFileName);
    byte[] mBuffer = new byte[1024];
    int mLength;

    try {
      // read the database from assets as a file
      while ((mLength = mInput.read(mBuffer)) > 0) {
          // write the database as a file to the internal storage using a byte stream buffer
          mOutput.write(mBuffer, 0, mLength);
      }
    }
    catch (IOException e) {
      Log.e(TAG, e.toString());
      throw new RuntimeException(e);
    }

    mOutput.flush();
    mOutput.close();
  }


  /**
   * Method that opens the database for performing operations on it
   *
   * @return whether the database could be successfully open or not
   * @throws SQLiteException if opening the database failed
   */
  public boolean openDataBase() throws SQLiteException {
    String mPath = DB_PATH + DB_NAME;

    try {
        mDataBase = SQLiteDatabase.openDatabase(mPath, null, SQLiteDatabase.OPEN_READONLY);
    }
    catch (SQLiteException mSQLiteException) {
        Log.e(TAG, mSQLiteException.toString());
    }

    return (mDataBase != null);
  }


  /**
   * Method that closes the database
   */
  @Override
  public synchronized void close() {
    if(mDataBase != null) {
      mDataBase.close();
    }
    super.close();
  }


  /**
   * Abstract method onCreate must be implemented in order to extend SQLiteOpenHelper
   */
	@Override
	public void onCreate(SQLiteDatabase db) { }


  /**
   * Abstract method onCreate must be implemented in order to extend SQLiteOpenHelper
   */
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

}