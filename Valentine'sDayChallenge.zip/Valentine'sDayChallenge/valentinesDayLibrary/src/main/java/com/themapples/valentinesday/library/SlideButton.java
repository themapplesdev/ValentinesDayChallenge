/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.themapples.valentinesday.library;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.SeekBar;


/**
 * Class which extends the SeekBar, overwrites the onTouchEvent and provides events
 * for simulating slide & unlock features
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class SlideButton extends SeekBar {

  private Drawable mThumb;
  private SlideButtonListener mListener;

  public SlideButton(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  /**
   * Method that sets the SeekBar listener
   *
   * @param listener the interface which provides the events signature methods
   */
  public void setSlideButtonListener(SlideButtonListener listener) {
    this.mListener = listener;
  }


  /**
   * Method that sets a Drawable resource as thumb image of the custom SeekBar
   *
   * @param thumb thumb image (movable sliding button) of the seek bar
   */
  @Override
  public void setThumb(Drawable thumb) {
    super.setThumb(thumb);
    this.mThumb = thumb;
  }


  /**
   * Method that overwrites the onTouchEvent and adds the new custom events and handling
   *
   * @param event event type which was captured by the touch listener
   * @return whether a valid thumb drag was captured
   */
  @Override
  public boolean onTouchEvent(@NonNull MotionEvent event) {
    // action down event captured
    if (event.getAction() == MotionEvent.ACTION_DOWN) {
      // thumb area selected, excluding touches along the rest of the SeekBar
      if (mThumb.getBounds().contains((int) event.getX(), (int) event.getY())) {
        super.onTouchEvent(event);
        // signal a valid touch on the thumb of the SeekBar
        handleSlidePressed();
      }
      // touch outside the thumb is invalid
      else {
        // signal that there is no valid slide movement using the thumb
        // touch events captured by the SeekBar anywhere other than on the thumb are ignored
        handleSlideReleased();
        setProgress(50);
        return false;
      }
    }
    else {
      // action up event captured
      if (event.getAction() == MotionEvent.ACTION_UP) {

        // thumb was released at the right end of the SeekBar, successful slide to the right
        if (getProgress() >= 85) {

          // signal that "done" was selected
          handleSlideDone();

          // move the thumb at the right end of the SeekBar
          setProgress(100);
        }
        else {

          // thumb was released at the left end of the SeekBar, successful slide to the left
          if (getProgress() <= 15) {

            // signal that "skip" was selected
            handleSlideSkip();

            // move the thumb at the left end of the SeekBar
            setProgress(0);
          }
          /* thumb was released somewhere in between the ends of the SeekBar, to soon to unlock
          either the "done" or "skip" action */
          else {

            // signal that no valid selection was performed and that the thumb state can be reset
            handleSlideReleased();

            // reset the thumb position back to its original position, in the middle
            setProgress(50);
          }
        }
      }
      // drag event captured
      else {
        super.onTouchEvent(event);

        // signal that the thumb was slided
        handleSlideDrag();
      }
    }

    return true;
  }

  // methods which will be implemented in the listening activity class
  // a valid touch on the thumb of the SeekBar
  private void handleSlidePressed() {
    mListener.handleSlidePressed();
  }

  //  no valid slide movement using the thumb
  private void handleSlideReleased() {
    mListener.handleSlideReleased();
  }

  // the thumb was dragged to the left end
  private void handleSlideSkip() {
    mListener.handleSlideSkip();
  }

  // the thumb was dragged to the right end
  private void handleSlideDone() {
    mListener.handleSlideDone();
  }

  // the thumb was dragged to either left or right
  private void handleSlideDrag() {
    mListener.handleSlideDrag();
  }

}
