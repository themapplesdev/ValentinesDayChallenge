/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.themapples.valentinesday.library;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteException;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.drawable.AnimationDrawable;
import android.os.Vibrator;
import android.hardware.SensorManager;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


/**
 * Activity which employs the shake event listener and generates a new challenge
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class ShakeActivity extends Activity  {

  private Boolean mSoundOn;
  private Boolean mActivityStopped;
  private SharedPreferences mSharedPrefs;
  private AnimationDrawable mFrameAnimation;
  private TextView mShakePlayerScore1TextView;
  private TextView mShakePlayerScore2TextView;
  private String mActivePlayer;
  private String mInactivePlayer;
  private String mNamePlayer1;
  private String mNamePlayer2;
  private String mRemainingChallengesList;
  private String mCurrentChallenge;
  private int mScorePlayer1;
  private int mScorePlayer2;
  private int mTurnNumber;
  private int mGameTotalRounds;
  private int mCurrentRound;
  private MediaPlayer mChallengeDoneSound;
  private MediaPlayer mChallengeSkipSound;
  private MediaPlayer mGameActivitySound;
  private SensorManager mSensorManager;
  private ShakeEventListener mSensorListener;
  private Vibrator mVibrator;
  private static final String TAG = "ShakeActivity";

  /**
   * Activity method called when the activity is first created
   */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_shake);

    mVibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
    mActivityStopped = false;

    Bundle extras = getIntent().getExtras();
    // find if activity was reached from the Challenge activity of the Menu activity
    Boolean mReachedByResume = (extras != null) && extras.getBoolean("reachedByResume");
    // find if activity was reached through the "skip" button or the "done" button
    Boolean mChallengeDone = (extras != null) && extras.getBoolean("challengeDone");

    mSharedPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
    mSoundOn = mSharedPrefs.getBoolean("soundOn", true);
    mTurnNumber = mSharedPrefs.getInt("turnNumber", 1);

    if(mSoundOn) {
      // not first round
      if (mTurnNumber != 1) {

        // activity was reached through the "resume" button from the Menu activity
        if (mReachedByResume) {
          mGameActivitySound = MediaPlayer.create(getBaseContext(),
              com.themapples.valentinesday.library.R.raw.game_activity_sound);
          PlaySound(mGameActivitySound, false);
        }
        // activity was reached through the "skip" or "done" button from the Challenge activity
        else {

          // activity was reached through the "done" button from the Challenge activity
          if (mChallengeDone) {
            mChallengeDoneSound = MediaPlayer.create(getBaseContext(),
                com.themapples.valentinesday.library.R.raw.challenge_done_sound);
            PlaySound(mChallengeDoneSound, false);
          }
          // activity was reached through the "skip" button from the Challenge activity
          else {
            mChallengeSkipSound = MediaPlayer.create(getBaseContext(),
                com.themapples.valentinesday.library.R.raw.challenge_skip_sound);
            PlaySound(mChallengeSkipSound, false);
          }
        }
      }
      // first round
      else {
        mGameActivitySound = MediaPlayer.create(getBaseContext(),
            com.themapples.valentinesday.library.R.raw.game_activity_sound);
        PlaySound(mGameActivitySound, false);
      }
    }

    Boolean gameExists = mSharedPrefs.getBoolean("gameExists", false);
    // a valid game is in progress
    if(gameExists) {
      mInactivePlayer = mSharedPrefs.getString("inactivePlayer", "");
      mActivePlayer = mSharedPrefs.getString("activePlayer", "");
      mNamePlayer1 = mSharedPrefs.getString("namePlayer1", "");
      mNamePlayer2 = mSharedPrefs.getString("namePlayer2", "");
      mRemainingChallengesList = mSharedPrefs.getString("remainingChallengesList", "");
      mScorePlayer1 = mSharedPrefs.getInt("scorePlayer1", 0);
      mScorePlayer2 = mSharedPrefs.getInt("scorePlayer2", 0);
      mGameTotalRounds = mSharedPrefs.getInt("gameTotalRounds", 0);
      mTurnNumber = mSharedPrefs.getInt("turnNumber", 1);
      mCurrentRound = (mTurnNumber + 1) / 2;
    }
    else {
      // this activity should not never have been reached without a valid game in progress
      Log.wtf(TAG, getString(R.string.error_should_not_be_here_at_all));
    }

    // the random shake array is populated with values specified in the application strings
    String[] shakeList = getResources().getStringArray(R.array.array_random_shakes);

    mShakePlayerScore1TextView = new TextView(this);
    mShakePlayerScore1TextView = (TextView)findViewById(R.id.shakePlayerScore1TextView);
    mShakePlayerScore1TextView.setText(mNamePlayer1 + ": " + mScorePlayer1);

    mShakePlayerScore2TextView = new TextView(this);
    mShakePlayerScore2TextView = (TextView)findViewById(R.id.shakePlayerScore2TextView);
    mShakePlayerScore2TextView.setText(mNamePlayer2 + ": " + mScorePlayer2);

    // activity was reached through the "done" button from the previous challenge activity
    if (mChallengeDone) {

      // play an animation to show that the inactive player's score has changed
      Animation anim = new AlphaAnimation(0.0f, 1.0f);
      anim.setDuration(100);  // blink duration
      anim.setStartOffset(15);
      anim.setRepeatMode(Animation.REVERSE);
      anim.setRepeatCount(10);

      if (mInactivePlayer.equals(mNamePlayer1)) {
        mShakePlayerScore1TextView.startAnimation(anim);
      }
      else {
        mShakePlayerScore2TextView.startAnimation(anim);
      }
    }

    // generate a random shake text
    Random randomGenerator = new Random();
    int randomIndex = randomGenerator.nextInt(shakeList.length);
    String shakeText = shakeList[randomIndex];

    // load custom font
    Typeface customFont = Typeface.createFromAsset(getAssets(), "ArchitectsDaughter.ttf");

    TextView shakeTextView = (TextView)findViewById(R.id.shakeTextView);
    shakeTextView.setTypeface(customFont);
		shakeTextView.setText(shakeText);

    TextView shakeRoundNumberTextView = (TextView)findViewById(R.id.shakeRoundNumberTextView);
		shakeRoundNumberTextView.setText("Round: " + mCurrentRound + " of " + mGameTotalRounds);

    TextView shakePlayerTurnTextView = (TextView)findViewById(R.id.shakePlayerTurnTextView);
    TextView shakeTurnToShakeItTextView = (TextView)findViewById(R.id.shakeTurnToShakeItTextView);
    shakePlayerTurnTextView.setTypeface(customFont);
    shakeTurnToShakeItTextView.setTypeface(customFont);
		String lastCharInPlayerName = mActivePlayer.substring(mActivePlayer.length() - 1);

		if(lastCharInPlayerName.equalsIgnoreCase("s")) {
			shakePlayerTurnTextView.setText(mActivePlayer + "'");
		}
		else {
			shakePlayerTurnTextView.setText(mActivePlayer + "'s");
		}

		// Type cast the Image View
    ImageView imageView = (ImageView) findViewById(R.id.imageAnimation);
		// Setting animation_list.xml as the background of the image view
		imageView.setBackgroundResource(R.drawable.frame_animation_list);
		// Type cast the Animation drawable
    mFrameAnimation = (AnimationDrawable) imageView.getBackground();

    // register the shake event listener
    mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
    mSensorListener = new ShakeEventListener();

	}


  /**
   * Activity method called when the activity is becoming visible to the user
   */
	@Override
	protected void onStart() {
		super.onStart();

    // shake event occurred
    mSensorListener.setOnShakeListener(new ShakeEventListener.OnShakeListener() {
      public void onShake() {

        // if ongoing, stop the blinking animations
        mShakePlayerScore1TextView.clearAnimation();
        mShakePlayerScore2TextView.clearAnimation();

        // de-register the shake event listener
        mSensorManager.unregisterListener(mSensorListener);

        // start a new asynchronous task for device vibration
        new AsynchronousVibrateTask().execute();

        // generate a new challenge to be displayed on the next activity
        mCurrentChallenge = generateChallenge();

        // store the newly generated challenge in shared preferences
        mSharedPrefs.edit().putString("currentChallenge", mCurrentChallenge).apply();

        try {
          // device has a vibrator
          if(mVibrator.hasVibrator()) {
            Thread.sleep(1000);
          }
          // device does not have a vibrator
          else {
            Thread.sleep(150);
          }
        }
        catch (InterruptedException e) {
          e.printStackTrace();
        }

        Intent intent = new Intent(getBaseContext(), ChallengeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
      finish();
      }
    });
	}


  /**
   * Activity method called when the activity will start interacting with the user
   */
  @Override
	protected void onResume() {
		super.onResume();

    // register the shake event listener
    mSensorManager.registerListener(mSensorListener,
        mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
        SensorManager.SENSOR_DELAY_UI);
	}


  /**
   * Activity method called when the system is about to start resuming a previous activity
   */
	@Override
	protected void onPause() {
		super.onPause();

    mActivityStopped = true;

    if(mSoundOn) {
      if (mChallengeDoneSound != null) {
        if (mChallengeDoneSound.isPlaying() || mChallengeDoneSound.isLooping()) {
          mChallengeDoneSound.stop();
        }
        mChallengeDoneSound.reset();
        mChallengeDoneSound.release();
        mChallengeDoneSound = null;
      }

      if (mChallengeSkipSound != null) {
        if (mChallengeSkipSound.isPlaying() || mChallengeSkipSound.isLooping()) {
          mChallengeSkipSound.stop();
        }
        mChallengeSkipSound.reset();
        mChallengeSkipSound.release();
        mChallengeSkipSound = null;
      }

      if (mGameActivitySound != null) {
        if (mGameActivitySound.isPlaying() || mGameActivitySound.isLooping()) {
          mGameActivitySound.stop();
        }
        mGameActivitySound.reset();
        mGameActivitySound.release();
        mGameActivitySound = null;
      }
    }

    // de-register the shake event listener
    mSensorManager.unregisterListener(mSensorListener);

    // save the game parameters when activity is not visible anymore
    mSharedPrefs.edit().putString("activePlayer", mActivePlayer).apply();
    mSharedPrefs.edit().putString("inactivePlayer", mInactivePlayer).apply();
    mSharedPrefs.edit().putString("namePlayer1", mNamePlayer1).apply();
    mSharedPrefs.edit().putString("namePlayer2", mNamePlayer2).apply();
    mSharedPrefs.edit().putString("remainingChallengesList", mRemainingChallengesList).apply();
    mSharedPrefs.edit().putInt("scorePlayer1", mScorePlayer1).apply();
    mSharedPrefs.edit().putInt("scorePlayer2", mScorePlayer2).apply();
    mSharedPrefs.edit().putInt("gameTotalRounds", mGameTotalRounds).apply();
    mSharedPrefs.edit().putInt("turnNumber", mTurnNumber).apply();
    mSharedPrefs.edit().putInt("currentRound", mCurrentRound).apply();
    mSharedPrefs.edit().putString("lastGameActivity", "ShakeActivity").apply();
	}


  /**
   * Activity method called when the activity has detected the user's press of the back key
   */
  @Override
  public void onBackPressed() {

    // store the last game activity, in oder to be able to restore it on resume game
    mSharedPrefs.edit().putString("lastGameActivity", "ShakeActivity").apply();

    try {
      /* since project classes are not visible in libraries,
      reflection is used to access the application menu */
      Intent intent = new Intent(getBaseContext(),
          Class.forName(getApplicationContext().getPackageName() + ".MenuActivity"));
      intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
      startActivity(intent);
    }
    catch (ClassNotFoundException e) {
      e.printStackTrace();
    }

    finish();
  }


  /**
   * Hook that is called when the window changes its focus
   *
   * @param hasFocus whether the window has focus or not at the present moment
   */
  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);

    if (hasFocus) {
      // start animation when activity is in focus
      mFrameAnimation.start();
    }
    else {
      // stop animation when activity is out of focus
      mFrameAnimation.stop();
    }
  }


  /**
   * Method that generates a new challenge
   *
   * @return  text of the newly generated challenge
   */
  private String generateChallenge() {

    mRemainingChallengesList = mSharedPrefs.getString("remainingChallengesList", "");

    // convert String of indices into List; the default whitespace delimiter is used
    Scanner scanner = new Scanner(mRemainingChallengesList);
    List<Integer> challengesList = new ArrayList<>();
    while (scanner.hasNextInt()) {
      challengesList.add(scanner.nextInt());
    }

    Random randomGenerator = new Random();
    //generate random number from 0 to challengesList.size()-1
    Integer randomNumber = randomGenerator.nextInt(challengesList.size());

    // id from challengesList, which is not the same as its db index
    Integer idToExtract = challengesList.get(randomNumber);
    String challengeIdToExtract = Integer.toString(idToExtract);

    DataBaseAdapter dbAdapter = new DataBaseAdapter(getApplicationContext());
    try {
      dbAdapter.open();
    }
    catch (SQLiteException sqle) {
      Log.e(TAG, sqle.toString());
    }

    try {
      // generate a new challenge
      mCurrentChallenge = dbAdapter.getChallenge(challengeIdToExtract);
    }
    catch (SQLiteException sqle) {
      Log.e(TAG, sqle.toString());
    }

    try {
      dbAdapter.close();
    }
    catch (SQLiteException sqle) {
      Log.e(TAG, sqle.toString());
    }

    /* remove the index of the generated challenge from the list the remaining challenges,
    to implement unique apparitions random */
    challengesList.remove(idToExtract);

    //reconstruct the string after the generated challenge was removed
    mRemainingChallengesList = "";
    for (int index = 0; index < challengesList.size(); index++) {
      mRemainingChallengesList = mRemainingChallengesList + challengesList.get(index) + " ";
    }

    return mCurrentChallenge;
  }


  /**
   * Asynchronous task that vibrates for 1 second in the background,
   * while the random challenge is being generated
   */
  private class AsynchronousVibrateTask extends AsyncTask<String, Integer, Boolean> {

    /**
     * Method invoked on the background thread immediately after onPreExecute finishes executing
     *
     * @param params the parameters sent to the task upon execution
     */
    @Override
    protected Boolean doInBackground(String... params) {

      if(!mActivityStopped) {
        if (mVibrator.hasVibrator()) {
          mVibrator.vibrate(1000);
        }
      }

      return null;
    }
  }


  /**
   * Method that plays a sound resource
   *
   * @param mediaPlayer the MediaPlayer object to be played
   * @param playInLoop  whether the sound is to be played once or in a continuous loop
   */
  public void PlaySound(MediaPlayer mediaPlayer, Boolean playInLoop) {

    if (mediaPlayer.isPlaying() || mediaPlayer.isLooping()) {
      mediaPlayer.pause();
    }

    if (playInLoop) {
      mediaPlayer.setLooping(true);
    }
    else {
      mediaPlayer.setLooping(false);
    }

    mediaPlayer.start();
  }

}
