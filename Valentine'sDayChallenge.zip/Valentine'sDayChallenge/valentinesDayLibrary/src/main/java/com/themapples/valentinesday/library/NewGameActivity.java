/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.themapples.valentinesday.library;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteException;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.TextKeyListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/**
 * Activity for setting up a new game configuration
 *
 * @author Bogdan Budisan
 * @version 1.0
 * @since 2015.01.01
 */
public class NewGameActivity extends Activity {

	private static Random mRandomGenerator;
	private List<Integer> mNamesIndexList;
	private AlertDialog mInvalidNamesAlertDialog;
	private EditText mEditTextName1;
	private EditText mEditTextName2;
	private TextView mCharacterCounter1;
	private TextView mCharacterCounter2;
  private SharedPreferences mSharedPrefs;
  private Boolean mSoundOn;
  private MediaPlayer mRandomNamesSound;
  private int mGameTotalRounds;
  private int MAX_NAMES_LENGTH = 15;  // is also set in layout textView property
  private static final String TAG = "NewGameActivity";

  /**
   * Activity method called when the activity is first created
   */
  @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new_game);

    mRandomGenerator = new Random();
    mSharedPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
    mGameTotalRounds = mSharedPrefs.getInt("totalRounds", 0);
    mSoundOn = mSharedPrefs.getBoolean("soundOn", true);

    // clear setings from any previous games
    mSharedPrefs.edit().putBoolean("gameExists", false).apply();
    mSharedPrefs.edit().putString("lastGameActivity", "").apply();

    // set custom font to title
    TextView newGameTitleTextView = (TextView) findViewById(R.id.newGameTitleTextView);
    Typeface customFont = Typeface.createFromAsset(getAssets(), "ArchitectsDaughter.ttf");
    newGameTitleTextView.setTypeface(customFont);

    mEditTextName1 = (EditText) findViewById(R.id.editTextName1);
    mEditTextName2 = (EditText) findViewById(R.id.editTextName2);

    // clear EditText values
		if (mEditTextName1.length() > 0) {
		    TextKeyListener.clear(mEditTextName1.getText());
		}
		if (mEditTextName2.length() > 0) {
		    TextKeyListener.clear(mEditTextName2.getText());
		}

    // set up the characters counters for the names EditTexts
    mCharacterCounter1 = (TextView) findViewById(R.id.characterCounter1);
    mCharacterCounter2 = (TextView) findViewById(R.id.characterCounter2);
    mCharacterCounter1.setText(getString(R.string.character_counter_label) + MAX_NAMES_LENGTH);
    mCharacterCounter2.setText(getString(R.string.character_counter_label) + MAX_NAMES_LENGTH);

    // the random names array is populated with values specified in the application strings
    final String[] randomNames = getResources().getStringArray(R.array.array_random_names);

    // generate an ArrayList of indexes corresponding to the list of possible random names
    mNamesIndexList = new ArrayList<Integer>();
    for (int index = 0; index < randomNames.length; index++) {
          mNamesIndexList.add(index);
    }

		ImageButton randomNamesButton = (ImageButton) findViewById(R.id.randomNamesButton);
		randomNamesButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {

        // release the MediaPlayer in case the button was pressed moments ago
        if (mSoundOn) {
          if (mRandomNamesSound != null) {
            if (mRandomNamesSound.isPlaying() || mRandomNamesSound.isLooping()) {
              mRandomNamesSound.stop();
            }
            mRandomNamesSound.reset();
            mRandomNamesSound.release();
            mRandomNamesSound = null;
          }
        }

        if (mSoundOn) {
          mRandomNamesSound = MediaPlayer.create(getBaseContext(),
              com.themapples.valentinesday.library.R.raw.random_names_sound);
          PlaySound(mRandomNamesSound, false);
        }

        // clear any previous values in the names EditTexts
        if (mEditTextName1.length() > 0) {
            TextKeyListener.clear(mEditTextName1.getText());
        }
        if (mEditTextName2.length() > 0) {
            TextKeyListener.clear(mEditTextName2.getText());
        }

        // generate the first random number
        Integer randomNumber1 =
            mRandomGenerator.nextInt(randomNames.length); //(0..totalNames)
        int randomIndex1 = mNamesIndexList.get(randomNumber1);
        String randomName1 = randomNames[randomIndex1];

        /* remove the previously generated number from the list,
         to avoid generating the same name twice */
        mNamesIndexList.remove(randomIndex1);

        // generate the second random number, different from the first
        Integer randomNumber2 =
            mRandomGenerator.nextInt(randomNames.length - 1);  //(0..totalNames-1)
        int randomIndex2 = mNamesIndexList.get(randomNumber2);
        String randomName2 = randomNames[randomIndex2];

        mNamesIndexList.add(randomNumber1, randomNumber1);

        // set the two generated names in the two EditText
        mEditTextName1.setText(randomName1);
        mEditTextName2.setText(randomName2);
			}
		});


    ImageButton startGameButton = (ImageButton) findViewById(R.id.startGameButton);
		startGameButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {

        // trim trailing and leading spaces from the players' names
        final String namePlayer1 = mEditTextName1.getText().toString().trim();
        final String namePlayer2 = mEditTextName2.getText().toString().trim();

        // blank names
        if ( (namePlayer1.equals("") || namePlayer1.length() == 0 ||
            namePlayer2.equals("") || namePlayer2.length() == 0) ) {
            showErrorDialogue(getString(R.string.dialog_blank_names_error));
        }
        else {
          // identical names
          if (namePlayer1.toLowerCase().equals(namePlayer2.toLowerCase())) {

              showErrorDialogue(getString(R.string.dialog_identical_names_error));
          }
          // valid names
          else {
            ArrayList<String> challengesIdsList = null;
            String remainingChallengesList;

            DataBaseAdapter dbAdapter = new DataBaseAdapter(getBaseContext());
            try {
                dbAdapter.open();
            }
            catch (SQLiteException sqlError) {
                Log.e(TAG, sqlError.toString());
            }

            try {
                // create the list of challenges which will appear in the game
                challengesIdsList = dbAdapter.getAllChallengeIds();
            }
            catch (SQLiteException sqlError) {
                Log.e(TAG, sqlError.toString());
            }

            // convert the ArrayList of Strings into a single String
            remainingChallengesList = IdsToString(challengesIdsList);

            try {
                dbAdapter.close();
            }
            catch (SQLiteException sqlError) {
                Log.e(TAG, sqlError.toString());
            }

            // save the parameters of the new game into shared preferences
            mSharedPrefs.edit().putBoolean("gameExists", true).apply();
            mSharedPrefs.edit().putString("activePlayer", namePlayer1).apply();
            mSharedPrefs.edit().putString("inactivePlayer", namePlayer2).apply();
            mSharedPrefs.edit().putString("namePlayer1", namePlayer1).apply();
            mSharedPrefs.edit().putString("namePlayer2", namePlayer2).apply();
            mSharedPrefs.edit().putString("currentChallenge", "").apply();
            mSharedPrefs.edit().putString("remainingChallengesList",
                remainingChallengesList).apply();
            mSharedPrefs.edit().putInt("scorePlayer1", 0).apply();
            mSharedPrefs.edit().putInt("scorePlayer2", 0).apply();
            mSharedPrefs.edit().putInt("turnNumber", 1).apply();
            mSharedPrefs.edit().putInt("gameTotalRounds", mGameTotalRounds).apply();

            Intent intent = new Intent(getBaseContext(), ShakeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
          }
        }
			}
		});
	}


  /**
   * Activity method called when the activity is becoming visible to the user
   */
	@Override
	protected void onStart() {
		super.onStart();

      // attach the text changed listeners to the player names EditTexts
      mEditTextName1.addTextChangedListener(characterCounter1Watcher);
      mEditTextName2.addTextChangedListener(characterCounter2Watcher);

	}


  /**
   * Activity method called when the system is about to start resuming a previous activity
   */
	@Override
	protected void onPause() {
		super.onPause();

		if(mInvalidNamesAlertDialog != null) {
      mInvalidNamesAlertDialog.dismiss();
		}

    if (mSoundOn) {
      if (mRandomNamesSound != null) {
        if (mRandomNamesSound.isPlaying() || mRandomNamesSound.isLooping()) {
          mRandomNamesSound.stop();
        }
        mRandomNamesSound.reset();
        mRandomNamesSound.release();
        mRandomNamesSound = null;
      }
    }
  }


  /**
   * Activity method called when the activity has detected the user's press of the back key
   */
  @Override
  public void onBackPressed() {

    try {
      /* since project classes are not visible in libraries,
      reflection is used to access the application menu */
      Intent intent = new Intent(getBaseContext(),
          Class.forName(getApplicationContext().getPackageName() + ".MenuActivity"));
      intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
      startActivity(intent);
      finish();
    }
    catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
  }


  /**
   * Method that displays an AlertDialog with a given message
   *
   * @param  message text which will appear as the AlertDialog message
   */
  private void showErrorDialogue(String message) {

    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
    dialogBuilder.setTitle(getString(R.string.dialog_title_error));
    dialogBuilder.setIcon(R.drawable.heart);
    dialogBuilder.setMessage(message);
    dialogBuilder.setCancelable(false);

    dialogBuilder.setPositiveButton(getString(R.string.dialog_button_ok),
        new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int id) {
            dialog.dismiss();
        }
    });

    mInvalidNamesAlertDialog = dialogBuilder.create();
    mInvalidNamesAlertDialog.show();
  }


  /**
   * TextWatcher method which is called when the 1st player's name EditText is changed
   */
  private final TextWatcher characterCounter1Watcher = new TextWatcher() {

    /**
     * Abstract method beforeTextChanged must be implemented to create a TextWatcher
     *
     * @param  s initial text whose content will changed
     * @param  start character position where the initial text will be changed
     * @param  count number of characters whose content will be changed in the initial text
     * @param  after length of the new text which will replace the old one
     */
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    /**
     * Method which updates the character counter when the value of the EditText has changed
     *
     * @param  s new text whose content has changed
     * @param  start character position where the new text has changed
     * @param  before length of the initial text which was replace by the new one
     * @param  count number of characters whose content has changed in the new text
     */
    public void onTextChanged(CharSequence s, int start, int before, int count) {
      mCharacterCounter1.setText(getString(R.string.character_counter_label) +
          String.valueOf(MAX_NAMES_LENGTH - s.length()));
    }

    /**
     * Abstract method afterTextChanged must be implemented in implement a TextWatcher
     *
     * @param  s text whose content has changed
     */
    public void afterTextChanged(Editable s) {
    }
  };


  /**
   * TextWatcher method which is called when the 2nd player's name EditText is changed
   */
  private final TextWatcher characterCounter2Watcher = new TextWatcher() {

    /**
     * Abstract method beforeTextChanged must be implemented to create a TextWatcher
     *
     * @param  s initial text whose content will changed
     * @param  start character position where the initial text will be changed
     * @param  count number of characters whose content will be changed in the initial text
     * @param  after length of the new text which will replace the old one
     */
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    /**
     * Method which updates the character counter when the value of the EditText has changed
     *
     * @param  s new text whose content has changed
     * @param  start character position where the new text has changed
     * @param  before length of the initial text which was replace by the new one
     * @param  count number of characters whose content has changed in the new text
     */
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        mCharacterCounter2.setText(getString(R.string.character_counter_label) +
            String.valueOf(MAX_NAMES_LENGTH - s.length()));
    }

    /**
     * Abstract method afterTextChanged must be implemented in implement a TextWatcher
     *
     * @param  s text whose content has changed
     */
    public void afterTextChanged(Editable s) {
    }
  };


  /**
   * Method that converts an ArrayList<String> into a single String
   *
   * @param  challengeIds ArrayList containing all the indexes of challenges as elements
   * @return  challengesList String containing all the indexes of challenges separated by space
   */
  private String IdsToString(ArrayList<String> challengeIds){

    String challengesList = "";
    for (String s : challengeIds) {
        challengesList += s + " ";
    }

    return challengesList;
  }


  /**
   * Method that plays a sound resource
   *
   * @param mediaPlayer the MediaPlayer object to be played
   * @param playInLoop  whether the sound is to be played once or in a continuous loop
   */
  public void PlaySound(MediaPlayer mediaPlayer, Boolean playInLoop) {

    if (mediaPlayer.isPlaying() || mediaPlayer.isLooping()) {
      mediaPlayer.pause();
    }

    if (playInLoop) {
      mediaPlayer.setLooping(true);
    }
    else {
      mediaPlayer.setLooping(false);
    }

    mediaPlayer.start();
  }

}
